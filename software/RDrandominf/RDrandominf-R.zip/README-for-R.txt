------------------------------------------------------------------------------
May 13, 2014

The folder RDrandominf-R.zip contains replication files for paper "Randomization Inference in the Regression Discontinuity Design: An Application to Party Advantages in the U.S. Senate", by Matias Cattaneo, Brigham Frandsen and Rocio Titiunik, revised and resubmitted to the Journal of Causal Inference. 
-------------------------------------------------------------------------------

To download paper	http://www-personal.umich.edu/~titiunik/papers/RD-randominf.pdf
To download zip file	https://sites.google.com/a/umich.edu/titiunik/software/randomization-inference-rd
To contact authors	titiunik@umich.edu

--------------------------------------------------------------------------------

File list

USSenate-data-1914-2010-Replication.dta		Replication data, a Stata 12 file 
01-chooseW-balance.R				R code that selects the window where local randomization holds using tests of the sharp null hypothesis for several predetermined covariates
02-estimation.R					R code that performs estimation and inference in window selected by code 01-choose-balance.R
RDrandominf-functions.R				R functions called by 01-choose-balance.R and 02-estimation.R 
README-for-R.txt				This file
