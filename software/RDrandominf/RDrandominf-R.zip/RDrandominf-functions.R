########################################################

# Window selector function
# Based on randomization-based tests of sharp null hypothesis for different covariates (using simulation-based p-values), difference in means test-statistic and fixed margins randomization
# Using minimum p-value within each window as loss function

#######################################################
selectWindow = function(X, r, c, wmax, wmin, wstep, M, verbose = TRUE, seed, alpha) {

    set.seed(seed, kind = "Mersenne-Twister", normal.kind = "Inversion")
    windows = seq(from=wmin, to=wmax, by=wstep)
    pvalmg = matrix(NA, nrow = length(windows), ncol = ncol(X))    
    Tr = (r >= c)
    if(!is.null(colnames(X))) {
        Xnms = colnames(X)
        colnames(pvalmg) = Xnms
    } else {
        Xnms = paste("X", seq(1,ncol(X),1), sep="")
    }    
    nms = c("win", "nTr", "nCo",  "minp", "minX")
    results = as.data.frame(matrix(NA, nrow = length(windows), ncol = length(nms) + ncol(X)))
    colnames(results) = c(nms,Xnms)
    colnames(pvalmg) = Xnms

    ## start iterating over grid of windows
    for(i in 1:length(windows)) {
        wr = windows[i]
        wl = -wr
        if(verbose) cat("Testing sharp null hypothesis in window [", wr,",", wl,"]", "\n")
        WW = (r >= wl) & (r<=wr)
        results[i,"win"] = wr
        results[i,"nTr"] = sum(WW & Tr == 1)
        results[i,"nCo"] = sum(WW & Tr == 0)
        
        ## calculate observed value of test statistc for each covariate v in window i
        Wo = numeric(ncol(X))    
        for(v in 1:ncol(X)) Wo[v] = mean(X[Tr==1 & WW & !is.na(X[,v]),v]) - mean(X[Tr==0 & WW & !is.na(X[,v]),v], na.rm = TRUE)
        
        ## start randomization inference simulations
        W_FM= matrix(NA, nrow=M, ncol = ncol(X))
        for(j in 1:M) {
            ## Simulate treatment assignment using fixed margins in the window
            Z = sample(Tr[WW],replace=FALSE)
            ## START ITERATING OVER ALL COVARIATES
            for(v in 1:ncol(X)) {
                nona = (!is.na(X[,v])) 
                Y = X[nona & WW,v]
                Zv = Z[nona[WW]]
                W_FM[j,v] = mean(Y[Zv==1]) - mean(Y[Zv==0]) # value of test statistic for simulation j
            } # end iterating over covariates
        } # end of M randomization inference simulations
        
        ## compute marginal (indidivual) pvalues
        for(v in 1:(ncol(X))) pvalmg[i,v] = sum(abs(W_FM[,v]) >= abs(Wo[v]))/M
        results[i,6:(6+ncol(X)-1)] = pvalmg[i,]
        results[i,"minp"] = min(pvalmg[i,])
        results[i,"minX"] = names(pvalmg[i,][order(pvalmg[i,], decreasing=FALSE)])[1]
    }# end iterating over windows

    indx = 1:length(windows)
    p = results[,"minp"]
    iwin = indx[p < alpha][1] - 1
    if(iwin >= 1) {
        wstar = windows[iwin]
        cat("\n------------------------------------------------\n")
        cat("Chosen window is [", wstar, ",", -wstar, "]","\n")
        cat("Minimum p-value in chosen window is", results[iwin,"minp"]," from covariate", results[iwin,"minX"],"\n")        
        cat("------------------------------------------------\n")        
    }
    if(iwin == 0) {
        cat("\n------------------------------------------------\n")        
        cat("Chosen window has zero length: there is no window where minp is less than", alpha, "\n")
        cat("------------------------------------------------\n")                
        wstar = NA
    }
    return(list(wstar = wstar, pstar=results[iwin,"minp"], results=results, call=list(M=M, wmax=wmax, wmin=wmin, wstep=wstep, seed=seed)))
}

########################################################

# Randomization-inference confidence intervals
# Constructed inverting randomization-based tests of sharp null hypothesis (using simulation-based p-values), difference in means test-statistic and fixed margins randomization

#######################################################
CI.mean.randominf.twosided <- function(Y, Tr, mc, statistic, alpha = 0.05, step, ss=546299, tl=-1, tu=1) {

  set.seed(ss)
  n.tr <- length(Y[Tr==1]) # margins are fixed so I don't need to recalculate these inside the MonteCarlos
  n.co <- length(Y[Tr==0])
  
  if (statistic=="mean")   w.obs  <- abs(mean(Y[Tr==1]) - mean(Y[Tr==0])) # observed mean difference 

  taus <- seq(tl, tu, by = step)     # all null hypothesis to be tested
  left <- TRUE
  count <- 0
  
  # Iterate over a range of null hypothesis
  for(t in taus) {
    cat("Testing hypothesis tau=", t, "\n")
    Yadj <- Y - (Tr * t)                            # adjusted outcome
    w.obs.adj <-  abs(mean(Yadj[Tr==1]) - mean(Yadj[Tr==0])) # adjusted observed test statistic
    res <- numeric(mc)
    cum <- 0
    for (i in 1:mc) {
      Tr.mc <- sample(Tr, replace=FALSE ,size = length(Tr))
      if (statistic=="mean")  w.mc  <- abs(mean(Yadj[Tr.mc==1]) - mean(Yadj[Tr.mc==0]))
                                       # since has abs(), it's effectively double-sided, rejects for large values
      if (w.mc >= w.obs.adj) cum <- cum +1
      res[i] <- w.mc
    } # end testing hypothesis for a given t 
  
    p.value <- sum(res >= w.obs.adj)/mc

    if (p.value <= alpha) {# H0 is rejected
      count <- count + 1
      cat("H is rejected for tau", t,", with Pval = ", p.value,"\n")
      if(!left & count==1) tu <- t
    }
    
    if (p.value > alpha) {# H0 is accepted
      cat("H is NOT rejected for tau", t,", with Pval = ", p.value, "\n")      
      if(left)  {
        tl <- t
        left <- FALSE
      } else {
        tu <- t
      }
      count <- 0
    }
    p.value.old <- p.value
    t.old <- t
  } # end looping over all t's
  cat("Difference in means is ",w.obs,"\n")  
  cat("95% CI is [",tl,",",tu,"]","\n")
  return(list(w.obs = w.obs, tl = tl, tu = tu, seed = ss))
}

########################### 
#
# Randomization inference for RD (simulation-based)
#
#############################
# Values returned
# rpval_mn_PI  randomization-based pvalue using difference-in-means test-statistic and binomial randomization within the window
# rpval_mn_FM  randomization-based pvalue using difference-in-means test-statistic and fixed-margins randomization within the window
# mno          actual observed difference in means within the window
# n            total observations within window
# nr           total treated observations within window
# pr           estimated probability of treatment within window (proportion of treated observations in window)

randominfRD2 <- function(M, Yr, Yl,cov.binary, exact=FALSE, fixed.margins=TRUE, binomial=FALSE) {
    rpval_mn_PI = NA
    rpval_mn_FM = NA
    tout=NA
    nullPI=NA
    
    nr = length(Yr)
    nl = length(Yl)
    n = nr + nl
    pr = nr/n    
    Y = c(Yr, Yl)
    T = c(rep(1,nr), rep(0,nl))
    
    mno = mean(Yr) - mean(Yl)        
    tout <- try(t.test(Yr, Yl, alternative = "two.sided", mu = 0, paired = FALSE, var.equal = FALSE, conf.level = 0.95))
    if(is(tout, "try-error")) tout = list(estimate=c(mean(Yr), mean(Yl)), p.value=NA)
    
    nullPI=NA  
    
    ## do simulations
    if(!exact) {
        mn_FM = numeric(M)
        mn_PI = numeric(M)
        ks_FM = numeric(M)
        ks_PI = numeric(M)
        wx_FM = numeric(M)
        wx_PI = numeric(M)
        nullPI = 0
        for(j in 1:M) {
            if(binomial) {
                ## using binomial with probability of treatment equal to estimated pi 
                indx.random = runif(length(Yr) + length(Yl))
                T_PI =  indx.random<=pr
                if((sum(T_PI)==(length(Yr) + length(Yl))) | (sum(T_PI)==0)) {
                    nullPI = nullPI+1
                    rpval_mn_PI[j] = NA                    
                }
                if((sum(T_PI)!=(length(Yr) + length(Yl))) & (sum(T_PI)!=0)) {
                    
                    mn_PI[j]= mean(Y[T_PI==1]) - mean(Y[T_PI==0])
                }
            }
            if(fixed.margins){
                ## using fixed margins
                T_FM = sample(T,replace=FALSE)
                mn_FM[j]= mean(Y[T_FM==1]) - mean(Y[T_FM==0])
            }
        } # end of M simulations

        rpval_mn_PI = rpval_mn_PI[!is.na(rpval_mn_PI)]
        
        if(binomial) {
            meanwx_PI = mean(wx_PI)
            rpval_mn_PI = sum(abs(mn_PI)>=abs(mno))/(M-nullPI)
        }
        if(fixed.margins) {
            meanwx_FM = mean(wx_FM)
            rpval_mn_FM = sum(abs(mn_FM)>=abs(mno))/M
        }
    }# end of simulation-based RI

    cat("\n------------------------------------------------\n")
    cat("Simulation-based p-value for difference-in-means statistic and fixed-margins randomization is", rpval_mn_FM, "\n")
    cat("Simulation-based p-value for difference-in-means statistic and binomial randomization is", rpval_mn_PI, "\n")    
    cat("Observed value of difference in means in this window", mno,"\n")        
    cat("------------------------------------------------\n")        
    
    return(list(rpval_mn_PI =  rpval_mn_PI, rpval_mn_FM = rpval_mn_FM,
                mno = mno, 
                nullPI=nullPI, pr=pr, n=n, nr=nr)
           )
}

