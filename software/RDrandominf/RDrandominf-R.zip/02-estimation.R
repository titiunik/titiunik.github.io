########################################################
#
# Part 2: Perform randomization-based inference in selected window (and also classical inference)
#
#
########################################################
rm(list = ls())
library(foreign)
library(rdrobust)

options(width=150)

# Load randomization and classic RD inference functions 
source("RDrandominf-functions.R")

## Set seed 
## seed used in paper for demvoteshfor1: 337124
## seed used in paper for demvoteshfor2: 590903

##############################
#
# Load data
# 
#############################
data <- read.dta("./USSenate-data-1914-2010-Replication.dta",convert.dates = FALSE, convert.factors = FALSE, missing.type = FALSE,convert.underscore = FALSE)
dim(data)
names(data)

# Options for functions
c = 0          # RD cutoff
M = 10000      # number of randomization inference simulations

###########################################
# OUTCOME: Democratic Vote Share at t+1
# Estimate treatment effect on using randomization inference and classical methods
# Estimation inside selected window [-0.75,0.75]
#
##########################################
Y  <- data$demvoteshfor1
Tr <- data$demwin
r  <- data$demmv
ii = !is.na(Y)
Y = Y[ii]
Tr = Tr[ii]
r = r[ii]

###########################################
#
# ESTIMATION IN [-0.750, 0.750] 
#
##########################################

# Choose window (see 01-chooseW-balance.R for window choice)
wr = +0.750; wl = -0.750;
WW = (r >= wl) & (r<=wr)

#######################################################
# Randomization inference: test sharp null of no treatment effect
# options for function
# M              number of simulations for pvalues
# Yr             outcome vector for treated observations
# Yl             outcome vector for control observations
# fixed.margins  should fixed-margins randomization be used? Either this of binomial must be TRUE
# binomial       should binomial randomization be used?
#######################################################
set.seed(337124) 
RIout <- randominfRD2(M=M, Yr=Y[Tr==1 & WW], Yl=Y[Tr==0 & WW], fixed.margins=TRUE, binomial = TRUE) # see RDrandominf-functions.R for details on all values returned by this function

######################################################
## Calculate 2-sided randomization inference Confidence intervals: inverting tests of the sharp null hypothesis in constant treatment effect model
## with fixed margins randomization and difference in means as test statistic

# Warning: seto CIstep to 0.1 to replicate results in the paper (takes a few hours to run)
######################################################

# options for function
alpha = 0.05   # 1-alpha confidence intervals
mc = M         # number of simulations for p-value
# statistic   test statistic used to test the sharp null hypothesis of no treatment effect for adjusted outcomes Yadj = Y - Tr * tau
tl = -100      # lower value of the grid of values for tau in constant treatment effect model 
tu =  100      # upper value of the grid of values for tau in constant treatment effect model
# Constant treatment effect model: Y1 = Y0 + tau where tau belongs to the inverval [tl,tu]
CIstep = 10  # increment for grid [tl,tu] of hypotheses tested -- WARNING: change to 0.1 to replicate results in the paper 
# 1-alpha confidence interval is all the hypothesis not rejected in [tl,tu]

rFMCI = CI.mean.randominf.twosided(Y=Y[WW], Tr=Tr[WW], mc=M, statistic="mean", alpha = alpha, tl=-100, tu=100, step=CIstep)

######################################################
## Hodghes-Lehman estimate
######################################################

wout <- wilcox.test(x=Y[Tr==1 & WW], y=Y[Tr==0 & WW], alternative = c("two.sided"), mu = 0, paired = FALSE, exact = TRUE, correct = TRUE, conf.level = 0.95, conf.int=TRUE)

######################################################
## Classical inference using rdrobust, see https://sites.google.com/a/umich.edu/rdrobust for details
## local linear
######################################################

bw = rdbwselect(Y,r,all=TRUE)
print(bw)
h.ik = bw["IK","h"]
rb = rdrobust(Y,r,all=TRUE, bwselect="IK")
cat("Print rdrobust results \n")
print(rb)

###########################################
# OUTCOME: Democratic Vote Share at t+2
# Estimate treatment effect on using randomization inference and classical methods
# Estimation inside selected window [-0.75,0.75]
#
##########################################

Y  <- data$demvoteshfor2
Tr <- data$demwin
r  <- data$demmv
ii = !is.na(Y)
Y = Y[ii]
Tr = Tr[ii]
r = r[ii]

###########################################
#
# ESTIMATION IN [-0.750, 0.750] 
#
##########################################

# Choose window (see 01-chooseW-balance.R for window choice)
wr = +0.750; wl = -0.750;
WW = (r >= wl) & (r<=wr)

#######################################################
# Randomization inference: test sharp null of no treatment effect
#######################################################
set.seed(590903)
RIout <- randominfRD2(M=M, Yr=Y[Tr==1 & WW], Yl=Y[Tr==0 & WW], fixed.margins=TRUE, binomial = TRUE)

######################################################
## Calculate 2-sided randomization inference Confidence intervals: inverting tests of the sharp null hypothesis in constant treatment effect model
## with fixed margins randomization and difference in means as test statistic

# Warning: seto CIstep to 0.1 to replicate results in the paper (takes a few hours to run)
######################################################

rFMCI = CI.mean.randominf.twosided(Y=Y[WW], Tr=Tr[WW], mc=M, statistic="mean", alpha = alpha, tl=-100, tu=100, step=CIstep)

######################################################
## Hodghes-Lehman estimate
######################################################

wout <- wilcox.test(x=Y[Tr==1 & WW], y=Y[Tr==0 & WW], alternative = c("two.sided"), mu = 0, paired = FALSE, exact = TRUE, correct = TRUE, conf.level = 0.95, conf.int=TRUE)

######################################################
## Classical inference using rdrobust, see https://sites.google.com/a/umich.edu/rdrobust for details
## local linear
######################################################
bw = rdbwselect(Y,r,all=TRUE)
print(bw)
h.ik = bw["IK","h"]
rb = rdrobust(Y,r,all=TRUE, bwselect="IK")
cat("Print rdrobust results \n")
print(rb)
