########################################################
#
# Replication code for "Randomization Inference in the Regression Discontinuity Design: An Application to Party Advantages in the U.S. Senate",
# by Matias Cattaneo, Brigham Frandsen and Rocio Titiunik
# Reivised and Resubmitted to Journal of Causal Inference 
#
# PART 1: Choose window with covariate balance tests
#
########################################################

rm(list = ls())
library(foreign)
options(width=200)
source("RDrandominf-functions.R")

##############################
#
# Load data
#
#############################

data <- read.dta("./USSenate-data-1914-2010-Replication.dta",convert.dates = FALSE, convert.factors = FALSE, missing.type = FALSE,convert.underscore = FALSE)
dim(data)
names(data)

# Select predetermined covariates to be used for window selector 
X  =  cbind(data$presdemvoteshlag1, data$population/1000000, data$demvoteshlag1, data$demvoteshlag2, data$demwinprv1, data$demwinprv2, data$dopen, data$dmidterm, data$dpresdem)
# Assign names to the covariates
colnames(X) =  c("Dem Presidential Vote", "Population", "Dem Senate Vote t-1",  "Dem Senate Vote t-2", "Dem Senate Win t-1", "Dem Senate Win t-2", "Open", "Midterm", "Dem President")

###########################

# Set parameters

##############################

# number of simulations for randomization inference
M = 10000

## RD cutoff 
c = 0

# define grid of windows: sequence of w values of the running variable; the null hypothesis of no treatment effect will be tested for every window [-w,w]
wmin  = 0.5   #start value for w
wmax  = 100   #end value   for w ==> warning: it takes a few hours to search the whole interval [0.5,100] -- setting wmax=2 is enough to recover the chosen window and takes a few minutes
wstep =0.125  #increment
alpha = 0.15  # cutoff significance level to choose window

# running variable
r = data$demmv

# Set seed equal to seed used to generate balance plot used in original JCI paper 
seed = 914738

###########################

# Window Selection Algorithm
 
##############################

wout = selectWindow(X=X, r=r, c=c, wmax=wmax, wmin=wmin, wstep=wstep, M=M, seed=seed, alpha=alpha, verbose=TRUE)

# take a look at results -- replicate Table 2 in paper ==> only if you run it with wmax=20 or larger
print(wout$results[c(1:5,9,13,77,157),c("win", "minp","minX")])

#######################################################
#
# Create plot -- Replicate Figure 1
# To replicate full figure, run it with wmax=100
#######################################################

minp = wout$results[,"minp"]
len =  wout$results[,"win"]
plot(x=len, y=minp, ylab = "Minimum p-value across all covariates", xlab="Upper limit of symmetric window [-r,r] around cutoff \n (Absolute value Democratic margin of victory at t)", yaxt="n", las=1, xlim=c(0,100))

abline(h = 0.15, col="red", lwd="2", lty="dashed")
abline(h = 0.05, col="blue", lwd="1", lty="dashed")
arrows(x0 = 30 , y0 = 0.35, x1 = wout$results[3,"win"] + 1, y1 = wout$results[3,"minp"], length=0.1, angle=40)
text(x=52, y=0.36, "P-value in chosen window [-0.75,0.75]")
axis(side = 2, tck = -.015, labels = NA, at=c(0, 0.05, 0.15, 0.30, 0.40))
axis(2, at=c(0, 0.05, 0.15, 0.30, 0.40), labels = c("0.00", "0.05","0.15","0.30","0.40"), lwd = 0, line = -.4, las = 1)


