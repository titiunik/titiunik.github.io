##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################
rm(list = ls())
library(foreign)
library(xtable)
library(boot)
library(equivalence)
library(MASS)
library(Hotelling)
options(width=250)
########################

# Main Analysis for covariates -- Year 2007 only 

#######################

## load functions
source("Randominf-functions.R")
source("equivalence-functions.R")
data = read.dta("ar-data-final-v12.dta")
data = data[data$year==2002,]

alpha = 0.05
CIstep = 0.001
SimulPvalSE = function(K,p=1/2) sqrt(p*(1-p)/K)  # Standard error of simulated p-value (maximum when p=1/2, where p is real pval)
M = 10000
SimulPvalSE(M)

r = function(x) as.numeric(sprintf("%.2f",x))

########################

# Covariate balance -- ALL

#######################

YY = cbind(data$votepercent, data$married_d, data$dmale, data$dem_d, data$dblack, data$attorney_d, data$age)
Ynms = c("Vote Share", "Married", "Male", "Democrat", "Black", "Attorney", "Age")

nms = c("Variable","NTr", "NCo", "muTr", "muCo", "diffmu", "CIttest", "pvalttest", "pvalraninf","CIraninf",
        "delta.star.2sttest.raw", "delta.star.2sttest.SD", "delta.star.2sri.Mn.raw", "delta.star.2sri.Mn.SD")
results = as.data.frame(matrix(NA, nrow=length(Ynms), ncol = length(nms)))
colnames(results) = nms    

Tr = data$lot_4
year = data$year

for(i in 1:ncol(YY)) {
    cat("Estimation for outcome" ,Ynms[i] ,  "\n")     
    ii = complete.cases(YY[,i])
    Y = YY[,i][ii]
    T = Tr[ii]
    yr = year[ii]    

    # Parametric t-test: null hypothesis of equal means and confidence interval for difference in means
    tout = t.test(Y[T==1], Y[T==0], conf.level=1-alpha, alternative='two.sided', mu=0)

    # Randomization inference: test of sharp null  and confidence interval under constant treamtent effect model
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=NULL, mechanism = 'fixed.margins', stat = 'diffmeans', block=FALSE, blockvar=yr, CI=FALSE, cigridmin=-20, cigridmax = 20, cigridstep = CIstep, alpha = alpha, seed=59873)    
    
    results[i,"Variable"]           = Ynms[i]
    results[i,"NTr"]                = sum(T==1)
    results[i,"NCo"]                = sum(T==0)
    results[i,"muTr"]               = r(tout$estimate[1])
    results[i,"muCo"]               = r(tout$estimate[2])
    results[i,"diffmu"]             = r(tout$estimate[1] - tout$estimate[2])
    results[i,"CIttest"]            = paste("[", r(tout$conf.int[1]), ",", r(tout$conf.int[2]),"]", sep="")
    results[i,"pvalttest"]          = r(tout$p.value)
    results[i,"pvalraninf"]         = r(riout$sharppval)
    results[i,"CIraninf"]           = paste("[", r(riout$cimeans$ciconn[1]), ",", r(riout$cimeans$ciconn[2]),"]", sep="")

    # Two-sided tests of Equivalence
    ## Tests of equivalence ==> based on parametric t-test, two-sided
    cat("\nOutcome:", Ynms[i], " -- Two-sided test of equivalence based on t-test\n")
    out = delta.star.Equiv(Y=Y,T=T,X=NULL, stat="ttest", side='two', alpha=alpha,  M=M, block=FALSE, blockvar=yr)
    results[i,"delta.star.2sttest.raw"] = r(out$delta.star)
    results[i,"delta.star.2sttest.SD"]  = r(out$delta.star.sd)

    ## Tests of equivalence ==> randomization-inference based difference-in-means, two-sided
    cat("\nOutcome:", Ynms[i], " -- Two-sided randomization-based test of equivalence based on difference in means \n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="RI-diffmeans", side='two', alpha=alpha,  M=M, block=FALSE, blockvar=yr)
    results[i,"delta.star.2sri.Mn.raw"] = r(out$delta.star)
    results[i,"delta.star.2sri.Mn.SD"]  = r(out$delta.star.sd)
}

#### Covariate balance, omnibus test using Hotelling's T^2 statistic and Maximum t-statistic accross all covarites
ii =  complete.cases(YY)
cat("There are ", sum(ii), " missing values \n")
X = YY[ii,]
T = Tr[ii]
yr = year[ii]

# Hotelling
out =  randominf(M=M, y=NULL, Tr=T, mechanism = 'fixed.margins', stat = 'hotelling', X = X , block=FALSE, blockvar=yr, CI=FALSE, cigridmin=-20, cigridmax = 20, cigridstep = CIstep, alpha = alpha, seed=59873)    

row = matrix(NA, ncol = ncol(results), nrow = 1)
colnames(row) = colnames(results)
row[,"Variable"] =  "Hotelling omnibus"
row[,"pvalraninf"] =  out$sharppval
row[,"pvalttest"]  =  hotelling.test(X[T==1,], X[T==0,], shrinkage = FALSE)$pval
results = rbind(results,row)

# Max t-stat
out =  randominf(M=M, y=NULL, Tr=T, mechanism = 'fixed.margins', stat = 'maxtstat', X = X , block=FALSE, blockvar=yr, CI=FALSE, cigridmin=-20, cigridmax = 20, cigridstep = CIstep, alpha = alpha, seed=59873)    

row = matrix(NA, ncol = ncol(results), nrow = 1)
colnames(row) = colnames(results)
row[,"Variable"] =  "Max abs. val. t-tstat"
row[,"pvalraninf"] =  out$sharppval
row[,"pvalttest"]  =  NA
results = rbind(results,row)

print(results)
resultsall = results

###############################################################

## Save all results

###############################################################
#save(resultsall, file="./output/covariates-2007.RData")
