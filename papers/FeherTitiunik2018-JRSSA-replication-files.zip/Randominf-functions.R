##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################
##################################

# Randomization-based inference functions

##################################
test.statistic = function(stat, Z, y, X) {
    if(stat == "diffmeans") {
        t = abs(mean(y[Z==1]) - mean(y[Z==0]))
    }

    if(stat == "diffmeans-adjlm") {
        e = lm(y ~ X)$residuals
        t = abs(mean(e[Z==1]) - mean(e[Z==0]))
    }

    if(stat == "diffmeans-adjrlm") {
        e = rlm(y ~ X, method = "M", maxit = 200)$residuals
        t = abs(mean(e[Z==1]) - mean(e[Z==0]))
    }

    if(stat == "diffmedians") {
        t = abs(median(y[Z==1]) - median(y[Z==0]))
    }

    if(stat == "diffmedians-adjlm") {
        e = lm(y ~ X)$residuals
        t = abs(median(e[Z==1]) - median(e[Z==0]))
    }
    
    if(stat == "ranksum") {
        nt = sum(Z == 1)
        nc = sum(Z == 0)
        E  = (nt * (nt + nc + 1))/2
        t  = abs(sum(rank(y, ties="average")[Z==1]) - E)
    }
    
    if(stat == "ranksum-adjlm") {
        e = lm(y ~ X)$residuals
        nt = sum(Z == 1)
        nc = sum(Z == 0)
        E  = (nt * (nt + nc + 1))/2
        rk = rank(e, ties="average")
        t = abs(sum(rk[Z==1]) - E)
    }
    
    if(stat == "ranksum-adjrlm") {
        e = rlm(y ~ X, method = "M", maxit = 200)$residuals
        nt = sum(Z == 1)
        nc = sum(Z == 0)
        E  = (nt * (nt + nc + 1))/2
        rk = rank(e, ties="average")        
        t = abs(sum(rk[Z==1]) - E)
    }

    if(stat == "diffaveranks") {
        nt = sum(Z == 1)
        nc = sum(Z == 0)
        rk = rank(y, ties="average")
        t = abs(mean(rk[Z==1]) - mean(rk[Z==0]))
    }

    if(stat == "diffaveranks-adjlm") {
        e = lm(y ~ X)$residuals        
        nt = sum(Z == 1)
        nc = sum(Z == 0)
        rk = rank(e, ties="average")
        t = abs(mean(rk[Z==1]) - mean(rk[Z==0]))
    }

    if(stat == "iqr") {
        t = abs(IQR(y[Z==1]) - IQR(y[Z==0]))
    }

    if(stat == "iqr-adjlm") {
        e = lm(y ~ X)$residuals                
        t = abs(IQR(e[Z==1]) - IQR(e[Z==0]))
    }

    if(stat == "diffvar") {
        t = abs(var(y[Z==1]) - var(y[Z==0]))
    }

    if(stat == "KS") {
        t = ks.test(y[Z==1], y[Z==0], alternative = 'two.sided')$statistic
    }

    if(stat == "KS-adjlm") {
        e = lm(y ~ X)$residuals                        
        t = ks.test(e[Z==1], e[Z==0], alternative = 'two.sided')$statistic
    }
    
    if(stat == "diffvar-adjlm") {
        e = lm(y ~ X)$residuals                        
        t = abs(var(e[Z==1]) - var(e[Z==0]))
    }
    
    if(stat == "hotelling") { # hotelling's T2 statistic 
        
        Xc = X[Z==0,]
        Xt = X[Z==1,]
        nc = sum(Z==0)
        nt = sum(Z==1)

        meanXc    = colMeans(Xc)
        meanXt    = colMeans(Xt)
        diffmeans = matrix(meanXt - meanXc, nrow = ncol(X), ncol = 1)

        Vc = var(Xc)
        Vt = var(Xt)

        t = as.numeric(t(diffmeans) %*% solve(Vc/nc + Vt/nt) %*% diffmeans)

        ## alternatively, use package
        ## library(Hotelling) 
        ## t2 = hotelling.stat(Xc, Xt, shrinkage = FALSE)$statistic
    }

    if(stat == "maxtstat") { 
    
        Xc = X[Z==0,]
        Xt = X[Z==1,]
        nc = sum(Z==0)
        nt = sum(Z==1)
        
        meanXc    = colMeans(Xc)
        meanXt    = colMeans(Xt)
        diffmeans = meanXt - meanXc
        V = sqrt(diag(var(Xc))/nc + diag(var(Xt))/nt)
        
        t = max(abs(diffmeans/V))
    }
    
    return(t)
}



random.assignment = function(Z, mechanism, pr, block, blockvar) {
    if(!block) {
        if(mechanism == 'fixed.margins') {
            Zs = sample(Z,replace=FALSE)
        }
        null = 0
        if(mechanism == 'binomial') {
            indx.random = runif(length(Z))
            Zs = as.numeric(indx.random<=pr)
            while((sum(Zs)==length(Z)) | (sum(Zs)==0)) {
                cat("Warning: Binomial random assignment resulted in all observations assigned to
              the same group, drawing assignment again \n")
                indx.random = runif(length(Z))
                Zs =  as.numeric(indx.random<=pr)
            }
        }
    } else {
          nl = as.numeric(levels(as.factor(blockvar)))
          nb = length(nl)
          if(mechanism == 'fixed.margins') {
              Zs = NULL
              for(i in 1:nb) {
                  Zs = c(Zs, sample(Z[blockvar==nl[i]],replace=FALSE))
              }
          }
          if(mechanism == 'binomial') {
              Zs = NULL
              for(i in 1:nb) {
                  indx.random = runif(length(Z[blockvar==nl[i]]))                  
                  Zs = c(Zs, as.numeric(indx.random<=pr))
              }              
          }      
      }
    return(Zs)
}

########################################################

# Randomization-inference confidence intervals
# Constructed inverting randomization-based tests of sharp null hypothesis (using simulation-based p-values), difference in means test-statistic and fixed margins randomization

#######################################################
CIcte <- function(y, Z, M, alpha = 0.05, stat, X, cigridmax, cigridmin, cigridstep, mechanism, pr, block, blockvar, verbose=verbose) {

    if(is.null(cigridmin))  cigridmin = min(y[Z==1]) - max(y[Z==0])
    if(is.null(cigridmax))  cigridmax = max(y[Z==1]) - min(y[Z==0])
    if(is.null(cigridstep)) cigridstep = (cigridmax - cigridmin)/100

    cigrid = seq(from=cigridmin, to=cigridmax, by=cigridstep)
    k = 1
    n.tr = sum(Z==1)
    n.co = sum(Z==0)
    left = 1
    enterleft = 0
    enterright = 0
    pvals = rep(NA,length(cigrid))

    j = 1
    j.old =1 
    pval.old = 0
    index = NULL
    speed = FALSE
    while(j < length(cigrid)) {
        ## Iterate over a range of null hypothesis
        t = cigrid[j]
        yadj = y - (Z * t)                            # adjusted outcome
        wo = test.statistic(stat=stat, Z=Z, y=yadj, X=X)
        w.mc =  numeric(M)
        cum =  0
        if(!block) {
            for (i in 1:M) {
                Zs      =  random.assignment(Z=Z, mechanism=mechanism, pr=pr, block=block, blockvar=blockvar)
                w.mc[i] =  test.statistic(stat=stat, Z=Zs, y=yadj, X=X)
            } # end testing hypothesis for a given t
        }
        if(block) {
            for (i in 1:M) {
                Zs =       random.assignment(Z=Z, mechanism=mechanism, pr=pr, block=block, blockvar=blockvar)
                w.mc[i] =  test.statistic(stat=stat, Z=Zs, y=yadj, X=X)
            } # end testing hypothesis for a given t
        }

        pval = sum(w.mc >= wo)/M       
        if(pval > alpha & j ==1 ) stop(paste("Stop. Grid is too narrow: first pval is", pval, sep=''))

        cat("\n Testing hypothesis tau=", t, " -- Pval =", pval, "\n")
        cat("pval = ", pval, "--- pval.old=", pval.old, "\n")
        cat("j = ", j, "--- j.old=", j.old, "\n")
        if( ((pval.old <= alpha & pval > alpha) | (pval.old > alpha & pval <= alpha)) & speed & ( j - j.old > 1 ) )   {
            j = j.old + 1
            if(verbose) cat("Jump is too large a jump, going backwards in the grid -- pval will not be stored \n")            
        } else {
            speed = TRUE
            pvals[j] = pval # this puts the pvalue in the corresponding element in the grid, leaving the values not visited NA
            index = c(index,j)
            j.old = j
            if(pval < 1e-04 | pval > 0.50) {
                j = j + 100 
            } else {
                if (pval < 1e-03 | pval > 0.40) {
                    j = j + 60 
                } else    {
                    if (pval < 1e-02 | pval > 0.30) {
                        j = j + 20
                    } else {
                        if (pval < 4e-02 | pval > 0.10) {
                            j = j + 5
                        } else {
                            j = j + 1
                            speed = FALSE
                        }
                    }
                }
            }
            pval.old = pval
        }
    }

    # A quick check
    if((length(pvals[index]) != length(pvals[!is.na(pvals)])) | (sum(abs(pvals[index] - pvals[!is.na(pvals)]))> 1e-04)) stop("Something is wrong with how the pvalues are stored")    

    pvals  = pvals[index]  
    cigrid = cigrid[index]
    
    resultsALL = data.frame(pval=pvals, tau=cigrid, indx=1:length(cigrid))
    resultsCI = resultsALL[pvals > alpha,]
    tl = resultsCI$tau[1]
    tu = resultsCI$tau[nrow(resultsCI)]
    il = resultsCI$indx[1]
    iu = resultsCI$indx[nrow(resultsCI)]

    cilarg = c(tl, tu)                
    ciconn = cilarg                   
    check = sum(pvals[il:iu] <= alpha)
    if(check > 0) {
        imax =  resultsCI$indx[resultsCI$pval == max(resultsCI$pval)][1]
        expandl = TRUE
        expandr = TRUE        
        ml = imax
        mr = imax
        while(expandr | expandl) {
            if(resultsALL$pval[(mr + 1)] > alpha) {
                mr = mr+1
            } else {
                expandr = FALSE
            }
            if(resultsALL$pval[(ml - 1)] > alpha) {
                ml = ml - 1
            }  else {
                expandl = FALSE
            }
        }
        ciconn=c(cigrid[ml], cigrid[mr])        
    }        

    return(list(cilarg = cilarg, ciconn=ciconn, connected = (check == 0), results=resultsALL))
}

########################### 
#
# Randomization inference
#
#############################
# Values returned
# rpval_mn_PI  randomization-based pvalue using difference-in-means test-statistic and binomial randomization
# rpval_mn_FM  randomization-based pvalue using difference-in-means test-statistic and fixed-margins randomization
# mno          actual observed difference in means within the window
# n            total observations
# nr           total treated observations
# pr           estimated probability of treatment

randominf <- function(M, y=NULL, ynm=NULL, Tr,  mechanism = 'fixed.margins', stat, X, CI=TRUE, cigridmin=NULL, cigridmax=NULL, cigridstep=NULL, civerbose=TRUE, alpha = 0.05, exact=FALSE, seed=NULL, block, blockvar) {
    if(stat == "hotelling" | stat=="maxtstat") omni = TRUE else omni = FALSE
    if(block) {
        # sort by block because simulated treatment vector is given in this order
        ii = order(as.factor(blockvar))
        if(!omni) y = y[ii] else X=X[ii,]
        Tr= Tr[ii]
        blockvar = blockvar[ii]
    }
    nr = sum(Tr==1) 
    nl = sum(Tr==0)
    n = nr + nl
    pr = nr/n    
    Z = Tr
    
    # Test sharp null
    wo = test.statistic(stat=stat, Z=Z, y=y, X=X)
    if(!exact) {
        if(!is.null(seed))  set.seed(seed, kind = "Mersenne-Twister", normal.kind = "Inversion")
        w.mc = numeric(M)
        for(i in 1:M) {
            Zs      = random.assignment(Z=Z, mechanism=mechanism, pr=pr, block=block, blockvar=blockvar)
            w.mc[i] =  test.statistic(stat=stat, Z=Zs, y=y, X=X)
        }

        pval = sum(w.mc >= wo)/M

    }
    # Hodghes-Lehmann estimate of location
    if(!omni) {
        h = suppressWarnings(wilcox.test(x=y[Z==1], y=y[Z==0], alternative = c("two.sided"), paired = FALSE, conf.int=TRUE)$estimate)
    } else {
        h = NA
    }
    cat("\n -------------------------------------------------  \n")
    cat("\n\n Starting confidence interval computation for outcome ", ynm, " using test-statistic " , stat, "\n")
    if(CI) {
        CI = CIcte(y=y, Z=Z, X=X, stat=stat, M=M, alpha = alpha, cigridmin=cigridmin, cigridmax=cigridmax, cigridstep=cigridstep,mechanism=mechanism, pr, verbose=civerbose, block=block, blockvar=blockvar)
    } else {
        CI = list(ciconn=c(NA,NA),cilarg=c(NA,NA))
    }
    cat("Finished confidence interval computation for outcome ", ynm, "\n")
    cat("\n -------------------------------------------------  \n")
        
    results = matrix(NA, nrow=4,ncol=1)
    colnames(results) = c("")    
    rownames(results) = c("Hodghes-Lehman Point Estimate", "Pvalue sharp null", paste((1-alpha)*100, "% CI Constant Treatment Effect (largest connected)", sep=""), paste((1-alpha)*100, "% CI Constant Treatment Effect (largest, possibly unconnected)",sep=''))
    results[1,1] = rr(h)
    results[2,1] = rr(pval)
    results[3,1] = paste("[",rr(CI$ciconn[1]), ",", rr(CI$ciconn[2]), "]", sep="")
    results[4,1] = paste("[",rr(CI$cilarg[1]), ",", rr(CI$cilarg[2]), "]", sep="")    

    call = match.call()

    cat("\nRandomization inference in the RD design: results for outcome ", ynm, "\n")
    
    cat("\nCall:\n")    
    print(call)
    cat("\nResults:\n")
    print(results, quote=FALSE)
    cat("Original grid used for CI calculations:", paste("[",cigridmin, ",", cigridmax, "]", sep=""),"\n")    
    cat("\nNumber of Control observations:", nl,"\n")
    cat("Number of Treated observations:", nr,"\n")
    cat("Test statistic:", stat,"\n")
    cat("Outcome:", ynm,"\n")    
    cat("-------------------------------------------\n\n")
    
    return(list(sharppval = pval, tobs=wo, pr=pr, nl=nl, nr=nr, n=n, CI = CI, hlest = h, call=call, cigridmin=cigridmin,cigridmax=cigridmax)
           )
}

# Function to round numbers 
rr = function(x) as.numeric(sprintf("%.4f",x))
#Para usarlo con una tabla: table.tex = apply(X,c(1,2),r)


