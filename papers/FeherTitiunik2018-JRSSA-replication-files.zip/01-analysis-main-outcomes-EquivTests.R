##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################
rm(list = ls())
library(foreign)
library(xtable)
library(boot)
library(equivalence)
options(width=250)

########################

# Main Analysis for outcomes ==> Tests of Equivalence

#######################

## load functions
source("Randominf-functions.R")
source("equivalence-functions.R")
data = read.dta("ar-data-final-v12.dta")

alpha = 0.05
CIstep = 0.01
SimulPvalSE = function(K,p=1/2) sqrt(p*(1-p)/K)  # Standard error of simulated p-value (maximum when p=1/2, where p is real pval)
M = 10000
SimulPvalSE(M)

r = function(x, d=2) round(x, digits=d)

########################

# Tests of Equivalence

#######################

absnoSF = data$abstention_rate
absnoSF[data$lastname == "FARIS"] = NA

YY = cbind(data$abstention_rate, absnoSF, data$num_resolution, data$bill_intros, data$pass_d, data$num_cosponsor)
Ynms = c("Abstentions", "Abstentions wo SF", "Resolutions", "Bills introduced", "Bills passed", "Bills Cosponsored")

#XX = cbind(data$votepercent, data$married_d, data$dmale, data$dem_d, data$dblack, data$attorney_d, data$age)
#Xnms = c("Vote Share", "Married", "Male", "Democrat", "Black", "Attorney", "Age")

XX = cbind(data$votepercent)
Xnms = c("Vote Share")

nms = c("Variable","NTr", "NCo",
        "delta.star.2sttest.raw", "delta.star.2sttest.SD",
        "delta.star.2sri.Mn.raw", "delta.star.2sri.Mn.SD", "delta.star.2sri.Rk.raw", "delta.star.2sri.Rk.SD", 
        "delta.star.1sttest.raw", "delta.star.1sttest.SD",
        "delta.star.1sri.Mn.raw", "delta.star.1sri.Mn.SD", "delta.star.1sri.Rk.raw", "delta.star.1sri.Rk.SD", 
        "sdPool", "sdCo")

results = as.data.frame(matrix(NA, nrow=length(Ynms), ncol = length(nms)))
colnames(results) = nms    

year = data$year
z = data$survive_d
Tr = data$lot_4

for(i in 1:ncol(YY)) {
    cat("Estimation for outcome" ,Ynms[i] ,  "\n")    
    ii = complete.cases(Tr, YY[,i])
    Y  = YY[,i][ii]     
    T  = Tr[ii]
    X  = XX[ii,]     
    yr = year[ii]

    results[i,"Variable"]           = Ynms[i]
    results[i,"NTr"]                = sum(T==1)
    results[i,"NCo"]                = sum(T==0)

    block = TRUE ; if(Ynms[i] == "Bills Cosponsored") block = FALSE

    # Two-sided tests of Equivalence
    ## Tests of equivalence ==> based on parametric t-test, two-sided
    cat("\nOutcome:", Ynms[i], " -- Two-sided test of equivalence based on t-test\n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="ttest", side='two', alpha=alpha,  M=M, block=block, blockvar=yr)
    results[i,"delta.star.2sttest.raw"] = r(out$delta.star)
    results[i,"delta.star.2sttest.SD"]  = r(out$delta.star.sd)
    results[i,"sdPool"] = r(out$sdPool)
    results[i,"sdCo"]   = r(out$sdCo)

    
    ## Tests of equivalence ==> randomization-inference based difference-in-means, two-sided
    cat("\nOutcome:", Ynms[i], " -- Two-sided randomization-based test of equivalence based on difference in means \n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="RI-diffmeans", side='two', alpha=alpha,  M=M, block=block, blockvar=yr)
    results[i,"delta.star.2sri.Mn.raw"] = r(out$delta.star)
    results[i,"delta.star.2sri.Mn.SD"]  = r(out$delta.star.sd)
    
    # Tests of equivalence ==> randomization-inference based on differnece in average ranks, two-sided
    cat("\nOutcome:", Ynms[i], " -- Two-sided randomization-based test of equivalence based on difference in average ranks \n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="RI-diffaveRk", side='two', alpha=alpha,  M=M, block=block, blockvar=yr)
    results[i,"delta.star.2sri.Rk.raw"] = r(out$delta.star)
    results[i,"delta.star.2sri.Rk.SD"]  = r(out$delta.star.sd)

    side = "smallH"
    if( Ynms[i] == "Abstentions" | Ynms[i] == "Abstentions wo SF") side = "largeH"
       
    ## One-sided tests of Equivalence
    ## Tests of equivalence ==> based on parametric t-test, one-sided
    cat("\nOutcome:", Ynms[i], " -- One-sided test of equivalence based on t-test\n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="ttest", side=side, alpha=alpha,  M=M, block=block, blockvar=yr)
    results[i,"delta.star.1sttest.raw"] = r(out$delta.star)
    results[i,"delta.star.1sttest.SD"]  = r(out$delta.star.sd)
    
    ## Tests of equivalence ==> randomization-inference based difference-in-means, one-sided
    cat("\nOutcome:", Ynms[i], " -- One-sided randomization-based test of equivalence based on difference in means \n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="RI-diffmeans", side=side, alpha=alpha,  M=M, block=block, blockvar=yr)
    results[i,"delta.star.1sri.Mn.raw"] = r(out$delta.star)
    results[i,"delta.star.1sri.Mn.SD"]  = r(out$delta.star.sd)
    
    ## Tests of equivalence ==> randomization-inference based on differnece in average ranks, one-sided
    cat("\nOutcome:", Ynms[i], " -- One-sided randomization-based test of equivalence based on difference in average ranks \n")
    out = delta.star.Equiv(Y=Y,T=T,X=X, stat="RI-diffaveRk", side=side, alpha=alpha,  M=M, block=block, blockvar=yr)
    results[i,"delta.star.1sri.Rk.raw"] = r(out$delta.star)
    results[i,"delta.star.1sri.Rk.SD"]  = r(out$delta.star.sd)

}
print(results)
#save(results, file="./output/outcomes-EquivTests.RData")
