##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################
library(foreign)
library(xtable)
library(boot)
options(width=250)
rm(list = ls())

########################
 
# Calculate bounds

#######################

## Bound functions
set.seed(654878)
source("bound-functions-v1.R")
stan = TRUE

M = 1000
data = read.dta("ar-data-final-v12.dta")

z = data$survive_d
Tr = data$lot_4
alpha = 0.05
absnoSF = data$abstention_rate
absnoSF[data$lastname == "FARIS"] = NA

YY = cbind(data$abstention_rate, absnoSF, data$num_resolution, data$bill_intros, data$pass_d, data$num_cosponsor)
Ynms = c("Abstentions", "Abstentions wo SF", "Resolutions", "Bills introduced", "Bills passed", "Bills Cosponsored")

dig = 3

nms = c("Variable","NTr", "NCo", "Prz_Tr", "Prz_Co", "mu1", "mu0", "tau", "mu", "ml", "mstep", "gu", "gl", "H-ATE-Up", "H-ATE-Lo", "Fix", "fixl", "fixu")
results = as.data.frame(matrix(NA, nrow=length(Ynms), ncol = length(nms)))
colnames(results) = nms    

########################

# Bounds for each outcome, standard

#######################
for(i in 1:ncol(YY)) {
    Y = YY[,i]
    cat("Calculating bounds for outcome" ,Ynms[i] ,  "\n")
    
    if(Ynms[i] == 'Abstentions wo SF' | Ynms[i] == "Bills Cosponsored") {
        if(Ynms[i] == 'Abstentions wo SF') ii = (data$lastname != "FARIS") else ii = (data$year== 2002)
        gl = quantile(Y[z==1 & ii], prob=0.25)
        gu = quantile(Y[z==1 & ii], prob=0.75)
        bout = bounds(z=z[ii], Tr = Tr[ii], Y=Y[ii], gl=gl, gu=gu, standard=TRUE, M=M, alpha=alpha)
        
    } else {
        gl = quantile(Y[z==1], prob=0.25)
        gu = quantile(Y[z==1], prob=0.75)
        bout = bounds(z=z, Tr = Tr, Y=Y, gl=gl, gu=gu, standard=TRUE, M=M, alpha=alpha)        
    }
        
    results[i,"Variable"]           = Ynms[i]
    results[i,"NTr"]                =  bout$N.Tr 
    results[i,"NCo"]                =  bout$N.Co 
    results[i,"Prz_Tr"]             =  bout$pz1.Tr 
    results[i,"Prz_Co"]             =  bout$pz1.Co 
    results[i,"gu"]          	    = gu
    results[i,"gl"]         	    = gl
    results[i,"H-ATE-Lo"]           = bout$H.ATE[1]
    results[i,"H-ATE-Up"]           = bout$H.ATE[2]
    results[i,"tau"]                = round(bout$tau, dig)
    results[i,"mu0"]                = round(bout$mu0, dig)
    results[i,"mu1"]                = round(bout$mu1, dig)
}
#save(results, file= "./output/bounds.RData")
