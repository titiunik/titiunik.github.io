##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################

#########################################

# Bounds function

#########################################

bounds = function(z, Tr, Y, gu, gl,alpha=0.05, verbose=FALSE, standard=TRUE, fixCo=TRUE, fixu, fixl, mu, ml, M=NULL) {
    Nt = sum(Tr==1)
    Nc = sum(Tr==0)    

    mu1 = mean(Y[z==1 & Tr==1])
    mu0 = mean(Y[z==1 & Tr==0])    
    
    if(standard) {
        yu = Y
        yu[z==0] = gu
        yl = Y
        yl[z==0] = gl
    } else {

        if(fixCo) {
            # impute missing outcome for controls, which are fixed at fixu and fixl
            # one possibility is to do fixu=gu and fixl=gl, but this is very stringent
            # a more sensible approach is to fix fixu and fixl at the observed values 
            yu = Y
            yu[z==0 & Tr==0] = fixu
            yl = Y
            yl[z==0 & Tr==0] = fixl

            # impute missing outcome for treatment
            yu[z==0 & Tr==1] = mu
            yl[z==0 & Tr==1] = ml
            
        } else {

            # impute missing outcome for treatments, which are fixed at fixu and fixl
            yu = Y
            yu[z==0 & Tr==1] = fixu
            yl = Y
            yl[z==0 & Tr==1] = fixl

            # impute missing outcome for control
            yu[z==0 & Tr==0] = mu
            yl[z==0 & Tr==0] = ml
        }
    }
    
    pz1.Tr = (1/Nt) * sum(z * Tr)
    pz1.Co = (1/Nc) * sum(z * (1-Tr)) 
    
    ub.Tr= (1/Nt) * sum(yu * z * Tr) + (1/Nt) * sum(yu * (1-z) * Tr)
    lb.Tr= (1/Nt) * sum(yl * z * Tr) + (1/Nt) * sum(yl * (1-z) * Tr)    
    H.Tr = c(lb.Tr, ub.Tr)
    if(verbose) {
        cat("Identification region for treated mean [",H.Tr[1], ",", H.Tr[2], "] \n") 
    }
    
    ub.Co= (1/Nc) * sum(yu * z * (1-Tr)) + (1/Nc) * sum(yu * (1-z) * (1-Tr))
    lb.Co= (1/Nc) * sum(yl * z * (1-Tr)) + (1/Nc) * sum(yl * (1-z) * (1-Tr))
    H.Co = c(lb.Co, ub.Co)
    if(verbose) {    
        cat("Identification region for treated mean [",H.Co[1], ",", H.Co[2], "] \n") 
    }
    H.ATE   = c(H.Tr[1] - H.Co[2], H.Tr[2] - H.Co[1])

    if(verbose) {
        cat("Identification region for ATE [",H.ATE[1], ",", H.ATE[2], "] \n") 
    }
    return(list(H.Tr=H.Tr, H.Co=H.Co, H.ATE=H.ATE, pz1.Tr = pz1.Tr, pz1.Co=pz1.Co, N.Tr = Nt, N.Co = Nc,
                mu1 = mu1, mu0=mu0, tau=mu1-mu0))
}



