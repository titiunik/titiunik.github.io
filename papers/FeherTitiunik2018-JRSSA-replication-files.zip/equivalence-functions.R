##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################

##################################

# Equivalence tests functions

##################################

library(equivalence)

equivtest = function(delta, Y, T, X=NULL, stat, alpha, M=NULL, side, block, blockvar)  {  
    if(stat == 'ttest') {
        # H0: abs(mu_Tr - mu_Co) >= delta
        
        # Test H0_larger: mu_Tr - mu_Co >= delta
        tl = t.test(Y[T==1], Y[T==0], mu=delta, alternative='less')
        pl = tl$p.value
        
        # Test H0_smaller: mu_Tr - mu_Co <= -delta
        ts = t.test(Y[T==1], Y[T==0], mu=-delta, alternative='greater')    
        ps = ts$p.value        
        reject = (pl <= alpha & ps <= alpha)
        
        # with equivalence package
        reject2 = (tost(Y[T==1], Y[T==0], epsilon=delta, alpha=alpha)$result == 'rejected')
    }

    if(stat == 'RI-diffmeans') {
        Yadjl = Y - (T * delta)                        # adjusted outcome for large hypothesis
        Yadjs = Y + (T * delta)                        # adjusted outcome for small hypothesis
        
        wOl = mean(Yadjl[T==1]) - mean(Yadjl[T==0])     # adjusted observed test statistic for large hypothesis
        wOs = mean(Yadjs[T==1]) - mean(Yadjs[T==0])     # adjusted observed test statistic for small hypothesis
        
        wl = numeric(M)
        ws = numeric(M)
        for(i in 1:M) {
            if(!block) {
                Z = sample(T, replace=FALSE)
            } else{
                ## sort by block because simulated treatment vector is given in this order
                ii = order(as.factor(blockvar))
                Y = Y[ii]
                T= T[ii]
                blockvar = blockvar[ii]
                Z =  random.assignment(Z=T, mechanism="fixed.margins", pr=NULL, block=block, blockvar=blockvar)
            }
            wl[i] = (mean(Yadjl[Z==1]) - mean(Yadjl[Z==0]))
            ws[i] = (mean(Yadjs[Z==1]) - mean(Yadjs[Z==0]))
        }
        pl = sum(wl <= wOl)/M
        ps = sum(ws >= wOs)/M
        reject = (pl <= alpha & ps <= alpha)
        reject2= NA
    }

    if(stat == 'RI-diffaveRk') {
        Yadjl = Y - (T * delta)                        # adjusted outcome for large hypothesis
        Yadjs = Y + (T * delta)                        # adjusted outcome for small hypothesis

        nt = sum(T == 1)
        nc = sum(T == 0)
        rkl = rank(Yadjl, ties="average")
        rks = rank(Yadjs, ties="average")        
        
        wOl = mean(rkl[T==1]) - mean(rkl[T==0])     # adjusted observed test statistic for large hypothesis
        wOs = mean(rks[T==1]) - mean(rks[T==0])     # adjusted observed test statistic for small hypothesis

        wl = numeric(M)
        ws = numeric(M)
        for(i in 1:M) {
            if(!block) {
                Z = sample(T, replace=FALSE)
            } else{
                ## sort by block because simulated treatment vector is given in this order
                ii = order(as.factor(blockvar))
                Y = Y[ii]
                T= T[ii]
                blockvar = blockvar[ii]
                Z =  random.assignment(Z=T, mechanism="fixed.margins", pr=NULL, block=block, blockvar=blockvar)
            }
        
            wl[i] = (mean(rkl[Z==1]) - mean(rkl[Z==0]))
            ws[i] = (mean(rks[Z==1]) - mean(rks[Z==0]))
        }
        pl = sum(wl <= wOl)/M
        ps = sum(ws >= wOs)/M
        reject = (pl <= alpha & ps <= alpha)
        reject2= NA
    }

    if(stat == 'RI-diffaveRkCov') {
        Yadjl = Y - (T * delta)                        # adjusted outcome for large hypothesis
        Yadjs = Y + (T * delta)                        # adjusted outcome for small hypothesis

        nt = sum(T == 1)
        nc = sum(T == 0)
        el = lm(Yadjl ~ X)$residuals
        es = lm(Yadjs ~ X)$residuals        
        
        rkl = rank(el, ties="average")
        rks = rank(es, ties="average")                
        
        wOl = mean(rkl[T==1]) - mean(rkl[T==0])     # adjusted observed test statistic for large hypothesis
        wOs = mean(rks[T==1]) - mean(rks[T==0])     # adjusted observed test statistic for small hypothesis

        wl = numeric(M)
        ws = numeric(M)
        for(i in 1:M) {
            if(!block) {
                Z = sample(T, replace=FALSE)
            } else{
                ## sort by block because simulated treatment vector is given in this order
                ii = order(as.factor(blockvar))
                Y = Y[ii]
                T= T[ii]
                blockvar = blockvar[ii]
                Z =  random.assignment(Z=T, mechanism="fixed.margins", pr=NULL, block=block, blockvar=blockvar)
            }
        
            wl[i] = (mean(rkl[Z==1]) - mean(rkl[Z==0]))
            ws[i] = (mean(rks[Z==1]) - mean(rks[Z==0]))
        }
        pl = sum(wl <= wOl)/M
        ps = sum(ws >= wOs)/M
        reject = (pl <= alpha & ps <= alpha)
        reject2= NA
    }
    
    return(list(rejectBoth = reject, rejectBoth.ttest=reject2, pval.LargeH =pl, pval.SmallH=ps, stat=stat))
}

delta.star.Equiv = function(Y, T, X, stat, alpha, M, side="two", block, blockvar, step.print=200)  {
    sdCo   = sd(Y[T==0])
    nt = sum(T==1) ; nc = sum(T==0)
    sdPool = sqrt((var(Y[T==0]) * (nc - 1)  + var(Y[T==1]) * (nt - 1)) / (nt - 1 + nc - 1))
    diff = (mean(Y[T==1]) - mean(Y[T==0]))

    deltas = seq(from=5 * sdPool, to=0 , by = -0.001 * sdPool)
    rej  = rep(NA, length(deltas))
    pvl = rep(NA, length(deltas))
    pvs = rep(NA, length(deltas))
    reject = TRUE
    i = 0
    j.old = -1
    while(reject) {
        i = i + 1
        j = floor(i/step.print)
        if(j.old < j) cat("Testing delta = ", deltas[i], "---iteration ", i, "\n");    j.old = j
        eout   = equivtest(Y=Y,T=T,M=M,X=X, delta=deltas[i], alpha=alpha,stat = stat, block=block, blockvar=blockvar)        

        rej[i]  = eout$rejectBoth
        pvl[i] = eout$pval.LargeH
        pvs[i] = eout$pval.SmallH

        if(side=="two") {
            reject = eout$rejectBoth
        } else {
            if(side == "smallH") reject = (eout$pval.SmallH <= alpha)
            if(side == "largeH") reject = (eout$pval.LargeH <= alpha)            
        }
    }
    if(i ==1 ) stop("Largest delta does not reject!")
    resttest        = cbind(delta=deltas, sd = deltas/sdPool, reject=rej, pval.SmallH=pvs, pval.LargeH=pvl)
    delta.star    = deltas[i]
    delta.star.sd = delta.star/sdPool

    return(list(delta.star=delta.star, delta.star.sd=delta.star.sd, resttest= resttest, stat, sdpool=sdPool, sdCo=sdCo,
                sd.used='sdpool', side=side, sdPool=sdPool, sdCo=sdCo))

}
