##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################
rm(list = ls())
library(foreign)
library(xtable)
library(boot)
library(equivalence)
options(width=250)

########################

# Main Analysis for outcomes

#######################

## load functions
source("Randominf-functions.R")
source("equivalence-functions.R")
data = read.dta("ar-data-final-v12.dta")  

alpha = 0.05
CIstep = 0.01
SimulPvalSE = function(K,p=1/2) sqrt(p*(1-p)/K)  # Standard error of simulated p-value (maximum when p=1/2, where p is real pval)
M = 10000
SimulPvalSE(M)

r = function(x, d=2) round(x, digits=d)

########################

# First do descriptive analysis 

#######################

YY = cbind(data$abstention_rate, data$num_resolution, data$bill_intros, data$pass_d, data$num_cosponsor)
Ynms = c("Abstentions", "Resolutions", "Bills introduced", "Bills passed", "Bills Cosponsored")

nms = c("Variable","NTr", "NCo", "minTr", "minCo", "maxTr", "maxCo", "muTr", "muCo", "medTr", "medCo", "sdTr", "sdCo", "1quTr", "1quCo", "3quTr", "3quCo","iqrTr", "iqrCo")
results = as.data.frame(matrix(NA, nrow=length(Ynms), ncol = length(nms)))
colnames(results) = nms    

year = data$year
z = data$survive_d
Tr = data$lot_4

for(i in 1:ncol(YY)) {
    cat("Estimation for outcome" ,Ynms[i] ,  "\n")    
    ii = complete.cases(Tr, YY[,i])
    Y = YY[,i][ii]     
    T = Tr[ii]
    yr = year[ii]

    results[i,"Variable"]           = Ynms[i]
    results[i,"NTr"]                = sum(T==1)
    results[i,"NCo"]                = sum(T==0)

    results[i,"minTr"]              = min(Y[T==1]) 
    results[i,"minCo"]              = min(Y[T==0])
    
    results[i,"maxTr"]              = max(Y[T==1]) 
    results[i,"maxCo"]              = max(Y[T==0])
    
    results[i,"muTr"]               = mean(Y[T==1]) 
    results[i,"muCo"]               = mean(Y[T==0])

    results[i,"medTr"]               = median(Y[T==1]) 
    results[i,"medCo"]               = median(Y[T==0])

    results[i,"sdTr"]               = sd(Y[T==1]) 
    results[i,"sdCo"]               = sd(Y[T==0])

    results[i,"1quTr"]               = quantile(Y[T==1], prob=1/4) 
    results[i,"1quCo"]               = quantile(Y[T==0], prob=1/4) 

    results[i,"3quTr"]               = quantile(Y[T==1], prob=3/4) 
    results[i,"3quCo"]               = quantile(Y[T==0], prob=3/4) 

    results[i,"iqrTr"]               = IQR(Y[T==1])
    results[i,"iqrCo"]               = IQR(Y[T==0])
}
results[,2:ncol(results)] = r(results[,2:ncol(results)])
print(results)
#print(xtable(results), file="./output/tab-outcomes-all-descriptive.tex")
#save(results, file="./output/outcomes-all-descriptive.RData")


########################

# Tests for each outcome: three different test statistics 

#######################
absnoSF = data$abstention_rate
absnoSF[data$lastname == "FARIS"] = NA

YY = cbind(data$abstention_rate, absnoSF, data$num_resolution, data$bill_intros, data$pass_d, data$num_cosponsor)
Ynms = c("Abstentions", "Abstentions wo SF", "Resolutions", "Bills introduced", "Bills passed", "Bills Cosponsored")

#XX = cbind(data$votepercent, data$dem_d)
#Xnms = c("Vote Share", "Democrat")

XX = cbind(data$votepercent)
Xnms = c("Vote Share")

nms = c("Variable","NTr", "NCo", "muTr", "muCo", "diffmu", "CIttest", "pvalttest", "pval.diffMn","CI.diffMn", "pval.diffMnCov","CI.diffMnCov", "pval.diffMed","CI.diffMed", "pval.diffRk","CI.diffRk", "pval.IQR","CI.IQR", "pval.KS","CI.KS", "pval.KSCov","CI.KSCov")
results = as.data.frame(matrix(NA, nrow=length(Ynms), ncol = length(nms)))
colnames(results) = nms    

year = data$year
z = data$survive_d
Tr = data$lot_4

for(i in 1:ncol(YY)) {
    # start clock
    ptm <- proc.time()
    cat("Estimation for outcome" ,Ynms[i] ,  "\n")    
    ii = complete.cases(Tr, YY[,i])
    Y  = YY[,i][ii]     
    T  = Tr[ii]
    X  = XX[ii,]     
    yr = year[ii]

    # Parametric t-test: null hypothesis of equal means and confidence interval for difference in means
    tout = t.test(Y[T==1], Y[T==0], conf.level=1-alpha, alternative='two.sided', mu=0)

    cigridmax = 20
    cigridmin = -20
    
    # Randomization inference: test of sharp null  and confidence interval under constant treamtent effect model
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=NULL, mechanism = 'fixed.margins', stat = 'diffmeans', block=TRUE, blockvar=yr, CI=TRUE, cigridmin=cigridmin, cigridmax = cigridmax, cigridstep = CIstep, alpha = alpha, seed=59873)    
    
    results[i,"Variable"]           = Ynms[i]
    results[i,"NTr"]                = sum(T==1)
    results[i,"NCo"]                = sum(T==0)
    results[i,"muTr"]               = r(tout$estimate[1])
    results[i,"muCo"]               = r(tout$estimate[2])
    results[i,"diffmu"]             = r(tout$estimate[1] - tout$estimate[2])
    results[i,"CIttest"]            = paste("[", r(tout$conf.int[1]), ",", r(tout$conf.int[2]),"]", sep="")
    results[i,"pvalttest"]          = r(tout$p.value)
    
    # Diffmeans
    results[i,"pval.diffMn"]         = r(riout$sharppval)
    results[i,"CI.diffMn"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")

    # Diff in means, with covariate adjustment
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=X, mechanism = 'fixed.margins', stat = 'diffmeans-adjlm', block=TRUE, blockvar=yr, CI=TRUE, cigridmin=cigridmin, cigridmax = cigridmax, cigridstep = CIstep, alpha = alpha, seed=59873)    
    results[i,"pval.diffMnCov"]         = r(riout$sharppval)
    results[i,"CI.diffMnCov"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")
    
    ## Difference in medians
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=X, mechanism = 'fixed.margins', stat = 'diffmedians', block=TRUE, blockvar=yr, CI=TRUE, cigridmin=cigridmin, cigridmax = cigridmax, cigridstep = CIstep, alpha = alpha, seed=59873)        
    results[i,"pval.diffMed"]         = r(riout$sharppval)
    results[i,"CI.diffMed"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")

    # Diff in average ranks
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=X, mechanism = 'fixed.margins', stat = 'diffaveranks', block=TRUE, blockvar=yr, CI=TRUE, cigridmin=-50, cigridmax = 50, cigridstep = CIstep, alpha = alpha, seed=59873)    
    results[i,"pval.diffRk"]         = r(riout$sharppval)
    results[i,"CI.diffRk"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")
    
    # Diff in inter-quartile range
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=X, mechanism = 'fixed.margins', stat = 'iqr', block=TRUE, blockvar=yr, CI=FALSE, cigridmin=-50, cigridmax = 50, cigridstep = CIstep, alpha = alpha, seed=59873)    
    results[i,"pval.IQR"]         = r(riout$sharppval)
    results[i,"CI.IQR"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")

    ## KS test statistic
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=NULL, mechanism = 'fixed.margins', stat = 'KS', block=TRUE, blockvar=yr, CI=TRUE, cigridmin=-50, cigridmax = 50, cigridstep = CIstep, alpha = alpha, seed=59873)    
    results[i,"pval.KS"]         = r(riout$sharppval)
    results[i,"CI.KS"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")

    ## Covariate adjusted KS test statistic
    riout =  randominf(M=M, y=Y, ynm = Ynms[i], Tr=T, X=X, mechanism = 'fixed.margins', stat = 'KS-adjlm', block=TRUE, blockvar=yr, CI=TRUE, cigridmin=-50, cigridmax = 50, cigridstep = CIstep, alpha = alpha, seed=59873)    
    results[i,"pval.KSCov"]         = r(riout$sharppval)
    results[i,"CI.KSCov"]           = paste("[", r(riout$CI$cilarg[1]), ",", r(riout$CI$cilarg[2]),"]", sep="")
    
    # stop clock
    cat("Finished all runs for outcome ", Ynms[i], " --- I took ", (proc.time() - ptm)[3], "seconds \n")
}
print(results)
#print(xtable(results), file="./output/tab-outcomes-all.tex")
#save(results, file="./output/outcomes-SharpNullCI.RData")
