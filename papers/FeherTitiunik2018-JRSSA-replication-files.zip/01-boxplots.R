##################################

# Feher and Titiunik (JRSSA, 2017) replication files

##################################
rm(list = ls())
library(foreign)
library(ggplot2)
options(width=250)
########################
# Boxplots
#######################
data = read.dta("ar-data-final-v12.dta")

## Introductions
dat = data[data$survive_d==1,]
dat$Tr = factor(dat$lot_4, levels=c(0,1), labels = c("Reelection-eligible", "Reelection-ineligible"))
p = ggplot(dat, aes(x=Tr, y=bill_intros, fill=Tr))
p = p + geom_boxplot(outlier.colour = NA)  + geom_point(position = position_jitter(width = 0.1))
p = p +  guides(fill=FALSE) + xlab("") + ylab("Number of Bills Introduced")
p = p + theme(axis.text.x = element_text(size=18,colour='black'), axis.text.y = element_text(size=18,colour='black'), text= element_text(size=18,colour='black'))
p
#ggsave("./output/boxplot-intros.pdf", plot = p)

## Passed
dat = data[data$survive_d==1,]
dat$Tr = factor(dat$lot_4, levels=c(0,1), labels = c("Reelection-eligible", "Reelection-ineligible"))
p = ggplot(dat, aes(x=Tr, y=pass_d, fill=Tr))
p = p + geom_boxplot(outlier.colour = NA)  + geom_point(position = position_jitter(width = 0.1))
p = p +  guides(fill=FALSE) + xlab("") + ylab("Number of Bills Passed")
p = p + theme(axis.text.x = element_text(size=18,colour='black'), axis.text.y = element_text(size=18,colour='black'), text= element_text(size=18,colour='black'))
p
#ggsave("./output/boxplot-passed.pdf", plot = p)

## Cosponsorships
dat = data[data$survive_d==1,]
dat$Tr = factor(dat$lot_4, levels=c(0,1), labels = c("Reelection-eligible", "Reelection-ineligible"))
p = ggplot(dat, aes(x=Tr, y=num_cosponsor, fill=Tr))
p = p + geom_boxplot(outlier.colour = NA)  + geom_point(position = position_jitter(width = 0.1))
p = p +  guides(fill=FALSE) + xlab("") + ylab("Number of Bills Cosponsored")
p = p + theme(axis.text.x = element_text(size=18,colour='black'), axis.text.y = element_text(size=18,colour='black'), text= element_text(size=18,colour='black'))
p
#ggsave("./output/boxplot-cosponsorships.pdf", plot = p)

## Resolutions
dat = data[data$survive_d==1,]
dat$Tr = factor(dat$lot_4, levels=c(0,1), labels = c("Reelection-eligible", "Reelection-ineligible"))
p = ggplot(dat, aes(x=Tr, y=num_resolution, fill=Tr))
p = p + geom_boxplot(outlier.colour = NA)  + geom_point(position = position_jitter(width = 0.1))
p = p +  guides(fill=FALSE) + xlab("") + ylab("Number of Resolutions Filed")
p = p + theme(axis.text.x = element_text(size=18,colour='black'), axis.text.y = element_text(size=18,colour='black'), text= element_text(size=18,colour='black'))
p
#ggsave("./output/boxplot-resolutions.pdf", plot = p)

## Abstentions w/ Steve Faris
dat = data[data$survive_d==1,]
dat$Tr = factor(dat$lot_4, levels=c(0,1), labels = c("Reelection-eligible", "Reelection-ineligible"))
p = ggplot(dat, aes(x=Tr, y=abstention_rate, fill=Tr))
p = p + geom_boxplot(outlier.colour = NA)  + geom_point(position = position_jitter(width = 0.1))
p = p +  guides(fill=FALSE) + xlab("") + ylab("Abstention Rate")
p = p + theme(axis.text.x = element_text(size=18,colour='black'), axis.text.y = element_text(size=18,colour='black'), text= element_text(size=18,colour='black'))
p
# Note: if we don't set outlier.colour=NA, the outlier is drawn when we call boxplot, and then it is called when we call jitter, so it appears twice!! Setting outlier.colour=NA fixes the problem
#p = p + geom_boxplot(outlier.colour = "black", outlier.shape=1)
#ggsave("./output/boxplot-abstentions.pdf", plot = p)

## Abstentions w/o Steve Faris
data = data[data$lastname!='FARIS',]
dat = data[data$survive_d==1,]
dat$Tr = factor(dat$lot_4, levels=c(0,1), labels = c("Reelection-eligible", "Reelection-ineligible"))
p = ggplot(dat, aes(x=Tr, y=abstention_rate, fill=Tr))
p = p + geom_boxplot(outlier.colour = NA)  + geom_point(position = position_jitter(width = 0.1))
p = p +  guides(fill=FALSE) + xlab("") + ylab("Abstention Rate")
p = p + theme(axis.text.x = element_text(size=18,colour='black'), axis.text.y = element_text(size=18,colour='black'), text= element_text(size=18,colour='black'))
p
#ggsave("./output/boxplot-abstentions-sansfaris.pdf", plot = p)


