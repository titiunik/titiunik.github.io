#################################
#
# Create plots for paper
# Adapted from code Blog_CoefficientPlots.R by Carlisle Rainey
#################################
rm(list = ls())
library(foreign)
source("CIplot-version2.R")

#################################
#
# Read data
#
#################################

data <- read.csv("./output/final-results-for-plots.csv")

# create a vector to store the variable names
levels(as.factor(data[,c("varname")]))
variables  <- c("Abstention Rate", "Bills Introduced", "Contributions", "Expenditures", "Nominate Score", "Legislator-District Distance")
titles <- c("(a) Abstention Rate", "(b) Bills Introduced", "", "", "(a) Nominate Score", "(b) Legislator-District Distance")
levels(as.factor(data[,c("vartype")]))
vartype.levels <- 1:6
vartype <- data$vartype

# create constant parameters
xlab = "Difference-in-means"
xlimlist = list(c(-0.1, 0.1), c(-50,50), c(-150,270), c(-120,340), c(-0.5,0.5), c(-10,10))
widthlist = c(5.5, 5.5, 6, 6, 5.5, 5.5)
heightlist = c(5.6, 5.6, 7, 7, 5.6, 5.6)
meancodigs = c(3, 1, 1, 1, 2, 2)
meancostart = c(0.05, 18, 130, 130, 0.24, 0.15)

for(i in 1:length(vartype.levels)) {
    indx = (data$vartype == vartype.levels[i] & data$description=="all")
    file = paste("./output/CIplot-", variables[i], ".pdf", sep="")
    CIplot(varnames=paste(data$state[indx],data$varname2[indx],sep=" "), xlim=xlimlist[[i]], xlab=xlab, est=data[indx,"coef"],
           se=data[indx,"se"], title=titles[i], file=file, addmeanco=TRUE, meanco=data[indx,"meanco"], meantr=data[indx,"meantr"], meancodigs=meancodigs[i], width=widthlist[i], height=heightlist[i])
}
