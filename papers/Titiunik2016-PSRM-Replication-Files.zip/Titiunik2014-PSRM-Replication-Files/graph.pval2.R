# Function to plot means and p-values

plot.pval <- function(results, title=NULL, legend,legendx=0.15,legendy=2.2, textsize=0.9, parcex=0.8, at1=-0.35, at2=-0.15, at3=-0.9,xlim1=-0.85, yheight = 0.5) {
  xlim = c(xlim1,1); pchset = c(21,24,22,23); pchcolset = c("blue","red")
  at1 <- at1; at2 <- at2; at3 <- at3
  par(cex=parcex, mai = c(0.5, 0.35, 1.1, 0.35))
  ny = nrow(results)

  if(!is.null(title))  plot(x=NULL,axes=F, xlim=xlim, ylim=c(1,ny-yheight),xlab="",ylab="", main=title)
  if(is.null(title))   plot(x=NULL,axes=F, xlim=xlim, ylim=c(1,ny-yheight),xlab="",ylab="")

  #axis(side=2,at=c(1:ny),las=1,tick=FALSE,labels=c(results[,1]))
  axis(side=1,at=c(0,0.05,0.1,1),tick=TRUE, las=2, cex.axis=0.7)
  axis(side=3,at=at1 + 0.05,labels="Mean\n2-yr",tick=FALSE, padj=0.5,cex.axis=textsize)
  axis(side=3,at=at2 - 0.00,labels="Mean\n4-yr",tick=FALSE, padj=0.5,cex.axis=textsize)
  #axis(side=3,at=at1 + 0.03, labels=expression(bar(x)[2]),tick=FALSE, padj=0.5,cex.axis = textsize)
  #axis(side=3,at=at2 - 0.02, labels=expression(bar(x)[4]),tick=FALSE, padj=0.5,cex.axis= textsize)
  axis(side=3,at=0.5,labels="P-values",tick=FALSE, padj=0.5,cex.axis= textsize) 
  
  for(i in 4:ncol(results)) points(results[,i],ny:1, pch = pchset[i-4+1], col = pchcolset[i-4+1], bg = pchcolset[i-4+1])
  abline(v=c(0,0.05,0.1),lty=c(1,4,4), lwd=c(1,2,2))
  for(i in 1:ny) {
    text(at3,ny-i+1,results[i,1],adj = 0,cex=textsize) # variable name
    text(at1,ny-i+1,results[i,2], cex=textsize)        # treatment mean
    text(at2,ny-i+1,results[i,3], cex=textsize)        # control mean
  }
  for(i in seq(2,by=2,length.out=floor((ny-1)/2))) abline(h = i+0.5, lty = 3)
  if(legend) legend(x=legendx, y=legendy, c("t-test pval", "KS-test pval"), pch=pchset, pt.bg = pchcolset, cex=0.8)
}
