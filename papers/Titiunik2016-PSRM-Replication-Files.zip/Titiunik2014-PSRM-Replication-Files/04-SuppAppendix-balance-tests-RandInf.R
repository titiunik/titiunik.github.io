###############################
#
# BALANCE TESTS USING RANDOMIZATION INFERENCE
#
###########################

rm(list=ls(all=TRUE))
library(foreign)
library(MASS)
library(stats)
library(Matching)
library(graphics)
library(lattice)
library(Hmisc)
#library(rmeta)

# Source Graph-pval function
source("graph.pval2.R")
# Source functions to perform randomization tests
source("randomization.tests.functions.R")


## Set seed
set.seed(84958, kind = "Mersenne-Twister", normal.kind = "Inversion")


###############################
#
# TEXAS
#
###########################
# Load data
data = read.dta("./dataTX-final.dta")

# Create unopposed dummy
data$dunop <- data$votesh_incumb==1

#########################################################
## Prepare covariates and clean covariate names 

###########################################################
# Covariates that are available for the three years
covar.all<-cbind(data[,"party"],data[,"gender"],data[,"dwhite_incumb"],data[,"dblack_incumb"],data[,"dhispa_incumb"],data[,"children"], data[,"age"], 

                 data[,"votesh_incumb"],data[,"dunop"], data[,"sen_seniority"],data[,"hou_seniority"],

                 data[,"dattorney"], data[,"dbusiness"], data[,"dmilitary"], data[,"dbaptist"], data[,"dcatholic"], data[,"dmethodist"],

                 data[,"dborntx"], data[,"dbornhouston"],
                 data[,"dmaster"], data[,"djd"], 

                 data[,"turnoutsh"],data[,"presvotesh_dem"],data[,"usrepvotesh_dem"], data[,"staterepvotesh_dem"],

                 data[,"govvotesh_dem"],data[,"ussenvotesh_dem"], 
                 
                 data[,"pop_hispanic18sh"], data[,"pop_white18sh"], data[,"pop_black18sh"])

names.covar.all<-c("Democrat", "Male", "White", "Black", "Hispanic","Children", "Age", 

                   "Vote incumb", "Unopposed","Senate terms", "House terms",
                   
                   "Attorney",  "Business",  "Military", "Baptist",  "Catholic",  "Methodist", 
                   
                   "Born TX", "Born Houston", 
                   "Master", "DJD",

                   "Turnout rate", "Vote Dem Pres", "Vote Dem USRep","Vote Dem StateRep",

                   "Vote Dem Gov", "Vote USSen",

                   "Share Hisp 18 pop", "Share white 18 pop", "Share black 18 pop")

colnames(covar.all)<- names.covar.all
length(colnames(covar.all))
length(names.covar.all)
dim(covar.all)

# Define year and treatment indicator
treat <- data[,"dshort_term"]
year  <- data[,"year"]
year[year==1995] <- 1993
print(year)
# replace 1995 to 1993 so I can filter both years doing year==1993 

# Set results matrix
nres    <- 4  # number of columns in the matrices, ie. number of tests that I report
results <- matrix(data=NA,ncol=nres,nrow=length(names.covar.all))
nm <- c("mean.tr", "mean.co","mean.pval", "d.pval") 
colnames(results) <- nm

## YEAR BY YEAR
results.year<-list(y9395=results, y03=results)
names.year <- list(y9395=c(names.covar.all), y03=c(names.covar.all))

for (k in 1:length(results.year)) {
  colnames(results.year[[k]])<-nm
}
years<-c(1993,2003)

for (j in 1:length(years)){
  for (i in 1:ncol(covar.all)) {
    cat("YEAR: ", years[j],"   VARIABLE: ", names.covar.all[i], "\n")
    x.tr <- covar.all[treat==1 & year==years[j],i]
    x.co <- covar.all[treat==0 & year==years[j],i]
    x.tr <- x.tr[!is.na(x.tr)]
    x.co <- x.co[!is.na(x.co)]
    dummy <- FALSE
    if( (sum(x.tr==1 | x.tr==0) + sum(x.co==1 | x.co==0)) == (length(x.tr)+length(x.co)))  dummy<-TRUE

    Tr <- treat[year==years[j] & !is.na(covar.all[,i])]
    x  <- covar.all[year==years[j] & !is.na(covar.all[,i]),i]
    
    mean    <- randominf.twosided (x = x, Tr = Tr, mc = 10000, statistic="mean")
    if(dummy) {
      d  <- list(p.value=NA)
    } else{
      d    <- randominf.twosided (x = x, Tr = Tr, mc = 10000, statistic="D")
    }

    results.year[[j]][i,1]  <- mean(x.tr)
    results.year[[j]][i,2]  <- mean(x.co)
    results.year[[j]][i,3]  <- mean$p.value
    results.year[[j]][i,4]  <- d$p.value
  }
}


TX.bal.results9395 <- cbind(names.year[[1]],format.df(results.year$y93,cdec=c(2,2,10,10,10),na.blank=TRUE, numeric.dollar= FALSE))
TX.bal.results03 <- cbind(names.year[[2]],format.df(results.year$y03,cdec=c(2,2,10,10,10),na.blank=TRUE, numeric.dollar= FALSE))

print(TX.bal.results9395)
print(TX.bal.results03)

pdf(file="./output/texas_balance_939503-RandInf.pdf",paper="USr", width = 11, height = 8.5)
par(mfcol=c(1,2))
plot.pval(rbind(TX.bal.results9395), title="(a) Texas 1993-1995", legend=TRUE,legendx=0.15,legendy=30.5)
plot.pval(rbind(TX.bal.results03), title="(b) Texas 2003", legend=TRUE,legendx=0.65,legendy=6.3)
dev.off()


###############################
#
# ARKANSAS
#
###########################
# Load data
data = read.dta("./dataAR-final.dta")

# Create unopposed dummy
data$dunop <- data$votesh==1

#########################################################
## Prepare covariates and clean covariate names 

###########################################################
covar.all <- data.frame(data[,"party"],data[,"gender"],data[,"dblack"], data[,"children"], data[,"age"],

                 data[,"votesh"],data[,"dunop"],data[,"sen_seniority"],data[,"hou_seniority"],

                 data[,"dattorney"], data[,"dbusiness"], data[,"dbaptist"], data[,"dpresbyterian"],
                
                 data[,"dbornlittlerock"],
                 data[,"dmarried"], 

                 data[,"usrepvotesh_dem"], data[,"ussenvotesh_dem"], data[,"govvotesh_dem"],
                
                 data[,"pop_hispanic18sh"], data[,"pop_white18sh"], data[,"pop_black18sh"])

# Alternatively, do it by hand and enter prettier names
names.covar.all<- c("Democrat", "Male", "Black", "Children", "Age",
                   
                   "Vote incumb", "Unopposed", "Senate terms", "House terms", 
                   
                   "Attorney", "Business", "Baptist",   "Presbyterian", 
                   
                   "Born Little Rock", 
                   "Married", 
                   
                   "Vote Dem USRep", "Vote Dem USSen", "Vote Dem Gov", 
                   
                   "Share Hisp 18 pop",  "Share white 18 pop", "Share black 18 pop")

apply(covar.all,2,function(x) sum(is.na(x)))
colnames(covar.all)<- names.covar.all
length(colnames(covar.all))
length(names.covar.all)
dim(covar.all)

# Define year and treatment indicator
treat <- data[,"dshort_term"]

# Set results matrix
nres    <- 4  # number of columns in the matrices, ie. number of tests that I report
results <- matrix(data=NA,ncol=nres,nrow=length(names.covar.all))
nm <- c("mean.tr", "mean.co","mean.pval", "d.pval") 
colnames(results) <- nm

for (i in 1:ncol(covar.all)) {
    cat("VARIABLE: ", names.covar.all[i], "\n")
    x.tr <- covar.all[treat==1,i]
    x.co <- covar.all[treat==0,i]
    x.tr <- x.tr[!is.na(x.tr)]
    x.co <- x.co[!is.na(x.co)]
    dummy <- FALSE
    if( (sum(x.tr==1 | x.tr==0) + sum(x.co==1 | x.co==0)) == (length(x.tr)+length(x.co)))  dummy<-TRUE

    Tr <- treat[!is.na(covar.all[,i])]
    x  <- covar.all[!is.na(covar.all[,i]),i]
    mean    <- randominf.twosided (x = x, Tr = Tr, mc = 10000, statistic="mean")
    if(dummy) {
      d  <- list(p.value=NA)
    } else{
      d    <- randominf.twosided (x = x, Tr = Tr, mc = 10000, statistic="D")
    }
    results[i,1]  <- mean(x.tr)
    results[i,2]  <- mean(x.co)
    results[i,3]  <- mean$p.value
    results[i,4]  <- d$p.value
}

AR.bal.results03 <- cbind(names.covar.all,format.df(results,cdec=c(2,2,10,10,10),na.blank=TRUE, numeric.dollar= FALSE))

###############################
#
# ILLINOIS
#
###########################
# Load data
data = read.dta("./dataIL-final.dta",  convert.factors=FALSE, convert.underscore = FALSE)

# Create unopposed dummy
data$dunop <- data$inc_votesh==1

## Prepare covariates
covar.all <-cbind(data[,"inc_ddemocrat"],
                data[,"inc_votesh"],data[,"duncontested"],
                data[,"inc_dincumb_2000"],
                data[,"gender"], data[,"dblack"], data[,"dhispanic"], data[,"age"], data[,"dma"], data[,"dlaw"],
                data[, "pop_hispanic18sh"], data[, "pop_white18sh"],data[, "pop_black18sh"],
                data[,"dopen"], data[, "house_votesh_dem"],
                data[,"house_open"], data[,"house_uncontested"],
                data[,"inc_ddefeat_incumb2000"]
                )

names.covar.all <- c("Democrat", 
                            "Vote incumb",  "Unopposed",
                            "Inc in 2000",
                            "Male", "Black", "Hispanic", "Age", "Master degree", "Law degree",
                            "Share Hisp 18 pop", "Share white 18 pop", "Share black 18 pop", 
                            "Open seat",  "Vote Dem StateRep",
                            "Open seat StateRep", "Unopposed StateRep",
                            "Defeated incumb"
                            )
apply(covar.all,2,function(x) sum(is.na(x)))
colnames(covar.all)<- names.covar.all
length(colnames(covar.all))
length(names.covar.all)
dim(covar.all)

# Define year and treatment indicator
treat <- data[,"dshort_term"]

# Set results matrix
nres    <- 4  # number of columns in the matrices, ie. number of tests that I report
results <- matrix(data=NA,ncol=nres,nrow=length(names.covar.all))
nm <- c("mean.tr", "mean.co","mean.pval", "d.pval") 
colnames(results) <- nm

for (i in 1:ncol(covar.all)) {
    cat("VARIABLE: ", names.covar.all[i], "\n")
    x.tr <- covar.all[treat==1,i]
    x.co <- covar.all[treat==0,i]
    x.tr <- x.tr[!is.na(x.tr)]
    x.co <- x.co[!is.na(x.co)]
    dummy <- FALSE
    if( (sum(x.tr==1 | x.tr==0) + sum(x.co==1 | x.co==0)) == (length(x.tr)+length(x.co)))  dummy<-TRUE

    Tr <- treat[!is.na(covar.all[,i])]
    x  <- covar.all[!is.na(covar.all[,i]),i]
    
    mean    <- randominf.twosided (x = x, Tr = Tr, mc = 10000, statistic="mean")
    if(dummy) {
      d  <- list(p.value=NA)
    } else{
      d    <- randominf.twosided (x = x, Tr = Tr, mc = 10000, statistic="D")
    }

    # compare to randomization inference
    results[i,1]  <- mean(x.tr)
    results[i,2]  <- mean(x.co)
    results[i,3]  <- mean$p.value
    results[i,4]  <- d$p.value
}

IL.bal.results03 <- cbind(names.covar.all,format.df(results,cdec=c(2,2,10,10,10),na.blank=TRUE, numeric.dollar= FALSE))

pdf(file="./output/arkansas_illinois_balance_03-RandInf.pdf",paper="USr", width = 11, height = 8.5)
par(mfcol=c(1,2))
plot.pval(rbind(AR.bal.results03), title="(a) Arkansas 2003", legend=TRUE,legendx=0.65,legendy=8.5)
plot.pval(rbind(IL.bal.results03), title="(b) Illinois 2003", legend=TRUE,legendx=0.65,legendy=12)
dev.off()

