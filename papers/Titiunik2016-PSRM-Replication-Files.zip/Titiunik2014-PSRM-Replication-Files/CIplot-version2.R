CIplot <- function(varnames, xlim, est, se, xlab, title, file=NULL, namesabove=TRUE, sep = 0.5, addmeanco=FALSE, meanco=NULL, meantr=NULL, meancodigs=NULL,width=7, height=7) {
    # sep ==> how much space between each confidence interval bar ==> a proportion between 0 and 1
    if(length(varnames) != length(est)) warning("STOP: length of variable names differs from length of estimates vector")
    if(!is.null(file)) pdf(file,width=width, height=height)
    
    ## set the graphical parameters
    par(
        family = "serif",  # I don't plot in anything but serif
        oma = c(0,0,0,0),  # Since it is a single plot, I set the outer margins to zero.
        mar = c(5,10,4,2)  # Inner margins are set through a little trial and error.
        )
    
    ## create an empty plot for total customization
    plot(NULL,                   
         xlim = xlim,
         ylim = c(0, (length(est)-1)/3 + 0.04),    # set ylim by the number of variables
         axes = F, xlab = NA, ylab = NA)           # turn off axes and labels

    ypos = 0.043
    ytop = (length(est)-1)/3 + 0.04
    xstep = (xlim[2]-xlim[1])/4
    if(addmeanco) text(xlim[1]-xstep,ytop, paste("Mean 4yr", sep=""), xpd = T, cex = .8)     # add means of Tr and Co to the side
    if(addmeanco) text(xlim[1]-xstep*2, ytop, paste("Mean 2yr", sep=""), xpd = T, cex = .8)     # add means of Tr and Co to the side    
    for (i in 1:length(est)) {                                                 # loop over a counter the length of the estimate vector
        points(est[i], ypos, pch = 19, cex = .5)                                  # add the points to the plot
        ##lines(c(est[i] + 1.64*se[i], est[i] - 1.64*se[i]), c(i, i))          # add the 90% confidence intervals  
        lines(c(est[i] + 1.96*se[i], est[i] - 1.96*se[i]), c(ypos, ypos))            # add the 95% confidence intervals
        if(!namesabove) text(xlim[1]-0.15, ypos, varnames[i], xpd = T, cex = .8)                    # add the variable names
        if(namesabove)  text(est[i], ypos, varnames[i], xpd = T, cex = .8, pos = 3)           # add variable labels above the points
        if(addmeanco) text(xlim[1]-xstep, ypos, paste(round(meanco[i],digits=meancodigs),ypos=""), xpd = T, cex = .8)     # add mean of control group to the side
        if(addmeanco) text(xlim[1]-xstep*2,   ypos, paste(round(meantr[i],digits=meancodigs),ypos=""), xpd = T, cex = .8)     # add mean of treatment group to the side        
        ypos = ypos + 0.30
    }
    
    ## add axes and labels
    axis(side = 1)                                                                                          # add bottom axis
    abline(v = 0, lty = 3, col = "grey")                                                                    # add verticle line
    mtext(side = 1, xlab, line = 3)                                                                         # label bottom axis
    mtext(side = 3, title, line = 1)                                                                        # add title
    box()                                                                                                   # add lines around the plot
    if(!is.null(file)) dev.off()
}    
