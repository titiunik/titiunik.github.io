
# RANDOMIZATION INFERENCE FUNCTIONS
# FUNCTIONS TO SIMULATE THE PROBABILITY DISTRIBUTION OF DIFFERENT TEST STATISTICS UNDER THE NULL OF NO TREATMENT EFFECT
# MONTE CARLO SIMULATIONS TO APROXIMATE THE DISTRIBUTION OF THE TEST STATISTIC UNDER THE NULL

ks.fast <- function(x, y)
 {
   n.x <- length(x)
   n.y <- length(y)
   w <- c(x, y)
   z <- cumsum(ifelse(order(w) <= n.x, 1/n.x, -1/n.y))
   z <- z[c(which(diff(sort(w)) != 0), n.x + n.y)]

   return( max(abs(z)) )
 } #ks.fast


# Randomization inference function, TWO SIDED

randominf.twosided <- function(x, Tr, mc, statistic) {
  
  n.tr <- length(x[Tr==1]) 
  n.co <- length(x[Tr==0])
  
  if (statistic=="mean")     w  <- abs(mean(x[Tr==1]) - mean(x[Tr==0]))
  if (statistic=="median")   w  <- abs(median(x[Tr==1]) - median(x[Tr==0]))
  if (statistic=="rank-sum") w  <- abs(sum(rank(x, ties.method = "average")[Tr==1]) - 1/2 * n.tr * (n.tr + n.co + 1))
  if (statistic=="D")        w  <- ks.fast(x=x[Tr==1], y=x[Tr==0])
  res <- numeric(mc)
  
  cum <- 0
  for (i in 1:mc) {
    Tr.mc <- sample(Tr, replace=FALSE ,size = length(Tr))
    
    if (statistic=="mean")      w.mc  <- abs(mean(x[Tr.mc==1]) - mean(x[Tr.mc==0]))       # since has abs(), I effectively make it double-sided and reject for large values
    if (statistic=="median")    w.mc  <- abs(median(x[Tr.mc==1]) - median(x[Tr.mc==0]))   # since has abs(), I effectively make it double-sided and reject for large values
    if (statistic=="rank-sum")  w.mc  <- abs(sum(rank(x, ties.method = "average")[Tr.mc==1]) - 1/2 * n.tr * (n.tr + n.co + 1))  # two-sided rank-sum test, see Lehmann page 24
    if (statistic=="D")         w.mc  <- ks.fast(x=x[Tr.mc==1], y=x[Tr.mc==0])            # since D stat is the abs(), rejects for large values and is double-sided by defn

    
    if (w.mc >= w) cum <- cum +1

    res[i] <- w.mc
  } # end for
  
  p.value <- sum(res >= w)/mc
  quant <- quantile(res,probs= c(0.025,0.975),type=8)

  if (statistic == "rank-sum") {
    ci.lower <- NULL
    ci.upper <- NULL
    hl <- hl(x,Tr)
  } else {
    ci.lower <- quant[[1]]
    ci.upper <- quant[[2]]
    hl <- NULL
  }
  return(list(p.value.test = cum/mc, p.value = p.value, results = res, ci.l = ci.lower, ci.u = ci.upper, hl = hl))
}

# Function to calculate the Hodges-Lehman estimator based on the Rank Sum test stastic with a single stratum
# See Rosenbaum  page 49

hl <- function (x,Tr) {

  x.tr <- x[Tr==1]
  x.co <- x[Tr==0]
  N.tr <- length(x.tr)
  N.co <- length(x.co)
  
  res <- numeric(N.tr * N.co)

  k <- 0 
  for (i in 1:N.tr) {
    for (j in 1:N.co){
      k <- k +1
      res[k] <- x.tr[i] - x.co[j]
    }
  }
  return(hl=median(res))
}  
