------------------------------------------------------------------------------
June 6, 2014

This folder contains the replication files for the paper "Drawing Your Senator From a Jar: Term Length and Legislative Behavior", by Rocio Titiunik, to appear in Political Science Research and Methods. 

-------------------------------------------------------------------------------

Author contact information			Rocio Titiunik
						Assistant Professor of Political Science
						University of Michigan
						titiunik@umich.edu

--------------------------------------------------------------------------------

File list

dataAR-final.dta				Replication data for Arkansas, Stata 12 file
dataIL-final.dta				Replication data for Illinois, Stata 12 file
dataTX-final.dta				Replication data for Texas, Stata 12 file
data-termlength-comparative.dta			Data on term length in national parliaments, for 70 democracies


01-balance-tests.R				R code to perform balance tests and figures
01-balance-tests-omnibus.do			Stata code to perform omnibus balance tests reported in footnote 18
02-analysis.do					Stata code to perform analysis			                                  
03-create-graphs.R				R code to create confidence interval plots
04-SuppAppendix-balance-tests-RandInf.R		R code to perform balance tests and figures using randomization inference (in Supplemental Appendix)
04-SuppAppendix-power-calculations.R		R code to perform power tests (in Supplemental Appendix)
CIplot-version2.R				R function called by 03-create-graphs.R
graph.pval2.R					R function called by 01-balance-tests.R and 04-SuppAppendix-balance-tests-RandInf.R
randomization.tests.functions.R			R function called by 04-SuppAppendix-balance-tests-RandInf.R	
./ouput/final-results-for-plots.csv		File that has results from analysis, and is used by 03-create-graphs.R to create confidence interval plots
./output					Output directory ==> The codes described above, if run, will save all estimation results (figures and other files) to this directory
README.txt					This file

	

