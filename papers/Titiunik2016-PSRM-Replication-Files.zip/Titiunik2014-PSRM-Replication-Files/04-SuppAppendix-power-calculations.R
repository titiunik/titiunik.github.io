#################################
#
# POwer calculations

#################################
rm(list = ls())
library(foreign)
library(pwr)

#################################
#
# Make power plots
#
###############################



#################################
#
# Bills introduced
#
###############################

# Arkansas Bill Introduction
data = read.dta("./dataAR-final.dta")
varnm = "Number Bills Introduced"
varnm2 = "NumberBillsIntroduced"
state = "Arkansas"
y = data$num_bls_int_sen_aut
sd = sqrt(var(y))
n1 = 17
n2 = 18
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")


# Texas Bill Introduction
data = read.dta("./dataTX-final.dta")
varnm = "Number Bills Introduced"
varnm2 = "NumberBillsIntroduced"
state = "Texas"
y = data$num_bls_int_sen_aut
sd = sqrt(var(y))
n1 = 15
n2 = 16
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")

# Illinois Bill Introduction
data = read.dta("./dataIL-final.dta")
varnm = "Number Bills Introduced"
varnm2 = "NumberBillsIntroduced"
state = "Illinois"
y = data$num_bls_int_sen_aut
sd = sqrt(var(y))
n1 = 19
n2 = 40
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")

###############
#
# Abstentions
#
###############################

# Arkansas Abstentions
data = read.dta("./dataAR-final.dta")
varnm = "Abstention Rate"
varnm2 = "AbstentionRate"
state = "Arkansas"
y = data$aepc_rate
sd = sqrt(var(y))
n1 = 17
n2 = 18
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")


# Texas Bill Abstentions
data = read.dta("./dataTX-final.dta")
varnm = "Abstention Rate"
varnm2 = "AbstentionRate"
state = "Texas"
y = data$aepc_rate
sd = sqrt(var(y))
n1 = 15
n2 = 16
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")

# Illinois Abstentions
data = read.dta("./dataIL-final.dta")
varnm = "Abstention Rate"
varnm2 = "AbstentionRate"
state = "Illinois"
y = data$abs_rate
sd = sqrt(var(y))
n1 = 19
n2 = 40
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")

###############
#
# Nominates
#
###############################

# Arkansas
data = read.dta("./dataAR-final.dta")
varnm = "NOMINATE Score"
varnm2 = "NOMINATEScore"
state = "Arkansas"
y = data$absnom
sd = sqrt(var(y))
n1 = 17
n2 = 18
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")


# Texas 
data = read.dta("./dataTX-final.dta")
varnm = "NOMINATE Score"
varnm2 = "NOMINATEScore"
state = "Texas"
y = data$absnom
sd = sqrt(var(y))
n1 = 15
n2 = 16
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")

# Illinois
data = read.dta("./dataIL-final.dta")
varnm = "NOMINATE Score"
varnm2 = "NOMINATEScore"
state = "Illinois"
y = data$absnom
sd = sqrt(var(y))
n1 = 19
n2 = 40
delta = seq(0.1, 1, by=0.05)
pp = numeric(length(delta))
maintit = paste("Power calculations for ", varnm, " in ", state, "\n Two-sided t-test of difference-in-means", sep="")
subtit = paste("Significance Level = 0.05, N1 =", n1, ", N2 = ", n2, ", SD=", round(sd,2), sep="")
for(i in 1:length(delta)) {
    pp[i] = pwr.t2n.test(n1 = n1, n2 = n2, d = delta[i], sig.level = 0.05, power = NULL, alternative = c("two.sided"))$power
    cat("Power for true effect on Bill Introduction equal to", delta[i], " is", pp[i], "\n")
}
# effect in levels
pdf(paste("./output/power-", state, "-", varnm2, "LV-effect.pdf", sep=""))
plot(delta*sd, pp, xlab="Effect size", ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
# effect in SDs
pdf(paste("./output/power-", state, "-", varnm2, "SD-effect.pdf", sep=""))
plot(delta, pp, xlab="Effect size as proportion of SD"                    , ylab="Power", main = maintit, sub=subtit, ylim = c(0,1), type="b", pch=21, col="black", bg="red")
dev.off()
#abline(h=0.6, col="red", lty="dashed")
#abline(h=0.8, col="red", lty="dashed")

